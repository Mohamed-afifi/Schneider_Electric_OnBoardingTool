import { Component } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  
 submit(){
  var email=document.getElementById('email');
  var password=document.getElementById('pass');
  window.open('reset\reset.component.html');
  alert('Submitted Successfuly');
}
}
