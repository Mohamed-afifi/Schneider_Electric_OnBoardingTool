import { Component } from '@angular/core';
import { FormGroup } from '@angular/forms';
import emailjs from '@emailjs/browser';

@Component({
  selector: 'app-reset',
  templateUrl: './reset.component.html',
  styleUrls: ['./reset.component.css']
})
export class ResetComponent {
  // form: FormGroup=this.fb.group({
    
  // })
  // send(){
  //   emailjs.send("service_rvxfzet","template_123",{
  //     from_name:'Schneider',
  //     to_name:'123',
  //     from_email:'Schneider.electric@se,com',
  //     subject:'reset Password'

  //   })
  // }

}
