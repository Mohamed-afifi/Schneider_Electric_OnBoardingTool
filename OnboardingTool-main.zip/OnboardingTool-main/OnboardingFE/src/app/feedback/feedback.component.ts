import { Component } from '@angular/core';

@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.css']
})
export class FeedbackComponent {
  button(id: any){
    document.getElementById(id)!.style.color='#5180ff';
    }
    submit(){
      alert('Submitted Successfully');
    }
}
