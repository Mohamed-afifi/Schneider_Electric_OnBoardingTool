import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ResetComponent } from './reset/reset.component';
import { EmployeeNavBarComponent } from '../user/components/employee-nav-bar/employee-nav-bar.component';
import { AdminNavBarComponent } from '../admin/admin-module/admin-nav-bar/admin-nav-bar.component';
import { ManagerNavBarComponent } from '../manager/manager-module/components/manager-nav-bar/manager-nav-bar.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule } from '@angular/material/dialog';
import { UserModuleModule } from 'src/user/user.module/user.module.module';
import { ManagerModuleModule } from 'src/manager/manager-module/manager-module.module';
import { AdminModuleModule } from 'src/admin/admin-module/admin-module.module';
// import { LoginComponent } from './login/login.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { EmployeebodyComponent } from './employeebody/employeebody.component';
import { ViewemployeeComponent } from './viewemployee/viewemployee.component';
import { AdminUpdatingManagerComponent } from './admin-updating-manager/admin-updating-manager.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { FaqsComponent } from './faqs/faqs.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { AllcoursesComponent } from './allcourses/allcourses.component';
import { CoursesComponent } from './courses/courses.component';
import { EnrolledcoursesComponent } from './enrolledcourses/enrolledcourses.component';
import { AdminNotificationComponent } from '../admin/admin-module/admin-notification/admin-notification.component';
import { HomeComponent } from './home/home.component';
// import { CoreModule } from './core/core.module';
import { SharedModule } from './shared-Module/shared/shared.module';
import { LoginComponent } from 'src/user/components/login/login.component';
import { AdminEmployeeComponent } from './admin-employee/admin-employee.component';
import { AdminAccessFeedbackManagerComponent } from './admin-access-feedback-manager/admin-access-feedback-manager.component';
import { AdminNotificationPageComponent } from './admin-notification-page/admin-notification-page.component';
import { HomeCoursesPageComponent } from './home-courses-page/home-courses-page.component';
import { AdminAddUserComponent } from './admin-add-user/admin-add-user.component';
import { AdminNewcomersComponent } from './admin-newcomers/admin-newcomers.component';
// import { ProfileComponent } from './profile/profile.component';



@NgModule({
  declarations: [
    AppComponent,
    ResetComponent,
    HeaderComponent,
    FooterComponent,
    // ProfileComponent,
    EmployeebodyComponent,
    ViewemployeeComponent,
    AdminUpdatingManagerComponent,
    HeaderComponent,
    FooterComponent,
    FaqsComponent,
    FeedbackComponent,
    AllcoursesComponent,
    CoursesComponent,
    EnrolledcoursesComponent,
    HomeComponent,
    FaqsComponent,
    AdminEmployeeComponent,
    AdminAccessFeedbackManagerComponent,
    AdminNotificationPageComponent,
    HomeCoursesPageComponent,
    AdminAddUserComponent,
    AdminNewcomersComponent
  ],
  imports: [
    BrowserModule,
    SharedModule,
    AppRoutingModule,
    MatButtonModule,
    MatDialogModule,
    ManagerModuleModule,
    AdminModuleModule,
    FormsModule,
    UserModuleModule,
  ],
  
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
