import { Component } from '@angular/core';

@Component({
  selector: 'app-enrolledcourses',
  templateUrl: './enrolledcourses.component.html',
  styleUrls: ['./enrolledcourses.component.css']
})
export class EnrolledcoursesComponent {

}
