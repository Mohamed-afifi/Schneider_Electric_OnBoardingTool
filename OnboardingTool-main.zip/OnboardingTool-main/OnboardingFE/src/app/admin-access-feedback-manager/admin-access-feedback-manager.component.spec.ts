import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminAccessFeedbackManagerComponent } from './admin-access-feedback-manager.component';

describe('AdminAccessFeedbackManagerComponent', () => {
  let component: AdminAccessFeedbackManagerComponent;
  let fixture: ComponentFixture<AdminAccessFeedbackManagerComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AdminAccessFeedbackManagerComponent]
    });
    fixture = TestBed.createComponent(AdminAccessFeedbackManagerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
