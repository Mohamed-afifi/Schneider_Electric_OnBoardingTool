import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-access-feedback-manager',
  templateUrl: './admin-access-feedback-manager.component.html',
  styleUrls: ['./admin-access-feedback-manager.component.css']
})
export class AdminAccessFeedbackManagerComponent {

}
