import { AdminAddUserComponent } from './admin-add-user/admin-add-user.component';
import { AdminNewcomersComponent } from './admin-newcomers/admin-newcomers.component';
import { HomeCoursesPageComponent } from './home-courses-page/home-courses-page.component';
import { AdminAccessFeedbackManagerComponent } from './admin-access-feedback-manager/admin-access-feedback-manager.component';
import { AdminEmployeeComponent } from './admin-employee/admin-employee.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ResetComponent } from './reset/reset.component';
import { ManagerNavBarComponent } from 'src/manager/manager-module/components/manager-nav-bar/manager-nav-bar.component';
import { AdminNavBarComponent } from 'src/admin/admin-module/admin-nav-bar/admin-nav-bar.component';
import { FaqsComponent } from './faqs/faqs.component';
import { AllcoursesComponent } from './allcourses/allcourses.component';
import { CoursesComponent } from './courses/courses.component';
import { EnrolledcoursesComponent } from './enrolledcourses/enrolledcourses.component';
import { ViewemployeeComponent } from './viewemployee/viewemployee.component';
import { EmployeebodyComponent } from './employeebody/employeebody.component';
import { AdminUpdatingManagerComponent } from './admin-updating-manager/admin-updating-manager.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { HomeComponent } from './home/home.component';
import { AdminNotificationComponent } from '../admin/admin-module/admin-notification/admin-notification.component';
import { LoginComponent } from 'src/user/components/login/login.component';
import { AdminNotificationPageComponent } from './admin-notification-page/admin-notification-page.component';
// import { PageNotFoundComponent } from 'src/shared-Module/components/page-not-found/page-not-found.component';

const routes: Routes = [
  {path:'',component: LoginComponent},
  {path:'faqs',component:FaqsComponent},
  {path:'allcourses',component:AllcoursesComponent},
  {path:'courses',component:CoursesComponent},
  {path:'enrolledcourses',component:EnrolledcoursesComponent},
  {path:'viewemployee',component:ViewemployeeComponent},
  {path:'employeebuddy',component:EmployeebodyComponent},
  {path:'admin-updating-manager',component:AdminUpdatingManagerComponent},
  {path:'feedback',component:FeedbackComponent},
  {path:'home',component:HomeComponent},
  {path:'admin-notification',component:AdminNotificationComponent},
  {path:'login',component: LoginComponent},
  {path:'rest',component:ResetComponent},
  {path:'manager',component:ManagerNavBarComponent},
  {path:'admin',component:AdminUpdatingManagerComponent},
  {path: 'admin-employee', component: AdminEmployeeComponent},
  {path: 'admin-access-feedback-manager', component: AdminAccessFeedbackManagerComponent},
  {path: 'admin-notification-page', component: AdminNotificationPageComponent},
  {path: 'home-courses-page', component: HomeCoursesPageComponent},
  {path: 'admin-newcomers', component: AdminNewcomersComponent},
  {path: 'admin-add-user', component: AdminAddUserComponent}
  


  // {path:'**',component: PageNotFoundComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
