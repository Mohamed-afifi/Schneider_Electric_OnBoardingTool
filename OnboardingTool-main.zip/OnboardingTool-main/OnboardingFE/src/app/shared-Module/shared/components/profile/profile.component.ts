import { Component } from '@angular/core';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent {
  experience=document.getElementsByName('Experence');
  addres=document.getElementsByName('Address');
  url?='assets/avatar.jpg';
  value="Fifth Setelnment"
  save(){
    this.value=this.value;
    alert("Changes saved");
  }
  discard(){
    alert("Changes discarded");
  }


  onSelectFile(event:any) { // called each time file input changes
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();

      reader.readAsDataURL(event.target.files[0]); // read file as data url

      reader.onload = (event) => { // called once readAsDataURL is completed
        this.url = event.target!.result as string;
      }
    }
}
  
  //  change(element:any) {
  //   element.setAttribute("oldvalue",this.value);
  // }

  // public f=false ;
  // isEnabled=true;
  // Txt="Edit Profile";
  // edit(){
  
  // if(this.f){
  // var x=document.getElementById("icon1");
  // x!.style.visibility="hidden";
  // var y=document.getElementById("icon2");
  // y!.style.visibility="hidden";
  // var x=document.getElementById("Experence");
  // this.isEnabled=true;
  // alert("Editting confirmed");
  // this.Txt="Edit Profile";
  // this.f=!this.f;

  // }
  // else{
  //   var x=document.getElementById("icon1");
  //   x!.style.visibility="visible";
  //   var y=document.getElementById("icon2");
  //   y!.style.visibility="visible";
  //   this.isEnabled=false;
  //   alert("You Can Now Start Editing");
  //   this.Txt="Confirm";
  //   this.f=!this.f;
  // }
  
  // }

}
