import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PageNotFoundComponent } from './components/page-not-found/page-not-found.component';
import { ProfileComponent } from './components/profile/profile.component';
import { Routes } from '@angular/router';

const routes: Routes = [
  {path:'profile',component:ProfileComponent},
];

@NgModule({
  declarations: [
    PageNotFoundComponent,
    ProfileComponent
  ],
  imports: [
    CommonModule
  ]
})
export class SharedModule { }
