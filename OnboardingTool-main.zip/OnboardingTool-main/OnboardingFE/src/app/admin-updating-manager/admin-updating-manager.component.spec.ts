import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminUpdatingManagerComponent } from './admin-updating-manager.component';

describe('AdminUpdatingManagerComponent', () => {
  let component: AdminUpdatingManagerComponent;
  let fixture: ComponentFixture<AdminUpdatingManagerComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AdminUpdatingManagerComponent]
    });
    fixture = TestBed.createComponent(AdminUpdatingManagerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
