import { Component } from '@angular/core';

@Component({
  selector: 'app-home-courses-page',
  templateUrl: './home-courses-page.component.html',
  styleUrls: ['./home-courses-page.component.css']
})
export class HomeCoursesPageComponent {

}
