import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-newcomers',
  templateUrl: './admin-newcomers.component.html',
  styleUrls: ['./admin-newcomers.component.css']
})
export class AdminNewcomersComponent {

}
