import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-notification-page',
  templateUrl: './admin-notification-page.component.html',
  styleUrls: ['./admin-notification-page.component.css']
})
export class AdminNotificationPageComponent {

}
