import { Component } from '@angular/core';

@Component({
  selector: 'app-employeebody',
  templateUrl: './employeebody.component.html',
  styleUrls: ['./employeebody.component.css']
})
export class EmployeebodyComponent {

}
