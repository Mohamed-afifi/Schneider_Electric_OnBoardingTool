import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ManagerNavBarComponent } from './components/manager-nav-bar/manager-nav-bar.component';



@NgModule({
  declarations: [
    ManagerNavBarComponent
  ],
  imports: [
    CommonModule
  ]
})
export class ManagerModuleModule { }
