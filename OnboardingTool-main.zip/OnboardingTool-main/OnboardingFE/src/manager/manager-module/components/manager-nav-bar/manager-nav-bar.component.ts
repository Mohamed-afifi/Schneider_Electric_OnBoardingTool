import { Component } from '@angular/core';

@Component({
  selector: 'app-manager-nav-bar',
  templateUrl: './manager-nav-bar.component.html',
  styleUrls: ['./manager-nav-bar.component.css']
})
export class ManagerNavBarComponent {

}
