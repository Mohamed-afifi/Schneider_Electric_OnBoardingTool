import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminNavBarComponent } from './admin-nav-bar/admin-nav-bar.component';
import { AdminUpdatingManagerComponent } from './admin-updating-manager/admin-updating-manager.component';
import { AdminNotificationComponent } from './admin-notification/admin-notification.component';



@NgModule({
  declarations: [AdminNavBarComponent,
  AdminUpdatingManagerComponent ,AdminNotificationComponent,],
  imports: [
    CommonModule
  ],
  exports: [AdminNavBarComponent ,AdminNotificationComponent ,AdminUpdatingManagerComponent ]
})
export class AdminModuleModule { }
