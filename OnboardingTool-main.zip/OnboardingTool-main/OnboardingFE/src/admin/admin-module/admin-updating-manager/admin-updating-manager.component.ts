import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-updating-manager',
  templateUrl: './admin-updating-manager.component.html',
  styleUrls: ['./admin-updating-manager.component.css']
})

export class AdminUpdatingManagerComponent {
  showDiv = true; 
  upgrade(){
    this.showDiv = false;
    alert("Upgrade was done Successfully");
  }
  dismiss(){
    alert("The Manager is dismissed");
  }
}
