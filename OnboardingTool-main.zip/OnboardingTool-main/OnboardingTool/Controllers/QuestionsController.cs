﻿using BoardingSystem.Interfaces;
using Microsoft.AspNetCore.Mvc;
using OnboardingTool.Data;
using OnboardingTool.Models.Domain;
using OnboardingTool.Services;

namespace OnboardingTool.Controllers
{
    [Route("api/")]
    [ApiController]
    public class QuestionsController : ControllerBase
    {

        private I_Question _questionService;

        public QuestionsController(OnBoardingContext db, I_Question QuestionService)
        {
            _questionService = QuestionService;
        }


        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]


        //retrieve random questions
        [HttpGet("/random-questions")]
        public List<Question> GetRandomQuestionsint(int course_id)
        {
            
            return _questionService.GetRandomQuestions(course_id);
        }
    }
}