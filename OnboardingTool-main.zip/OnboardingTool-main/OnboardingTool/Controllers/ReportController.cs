﻿using System.Collections.Generic;
using BoardingSystem.Interfaces;
using Microsoft.AspNetCore.Mvc;
using OnboardingTool.Data;
using OnboardingTool.Interfaces;
using OnboardingTool.Models.Domain;

namespace OnboardingTool.Controllers
{
    [Route("api/")]
    [ApiController]
    public class ReportController : ControllerBase
    {

        private I_Report _reportService;

        public ReportController(OnBoardingContext db, I_Report ReportService)
        {
            _reportService = ReportService;
        }

        [HttpPost("/ReportAProblem")]
        public string reportProblem(int eid, string pDescription)
        {
            return _reportService.reportProblem(eid, pDescription);
        }

        [HttpGet("/CourseReport")]
        public string Report(int eid, int cid)
        {
            return _reportService.Report(eid, cid);
        }
        [HttpGet("/ShowReportProblems")]
        public List<Report> showReportproblem()
        {
            return _reportService.showReportproblem();
        }
    }
}
