﻿using System.Collections.Generic;
using BoardingSystem.Interfaces;
using Microsoft.AspNetCore.Mvc;
using OnboardingTool.Data;
using OnboardingTool.Interfaces;
using OnboardingTool.Models.Domain;
using OnboardingTool.Services;

namespace OnboardingTool.Controllers
{
    [Route("api/")]
    [ApiController]
    public class ResourcesController : ControllerBase
    {
        private I_Resources _resourceService;

        public ResourcesController(OnBoardingContext db, I_Resources ResourceService)
        {
            _resourceService = ResourceService;
        }

        [HttpGet("/ViewContactInfo")]
        public List<Resources> viewContactInfo()
        {

            return _resourceService.viewContactInfo();

        }


        [HttpPost("/AddResources")]
        public string addResource(string contactInfo, string companyPolicy, string usefulLink)
        {
            return _resourceService.addResource(contactInfo, companyPolicy, usefulLink);
        }

    }
}
