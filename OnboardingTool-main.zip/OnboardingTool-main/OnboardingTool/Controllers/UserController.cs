﻿using BoardingSystem.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OnboardingTool.Data;
using OnboardingTool.Interfaces;
using OnboardingTool.Models.Domain;
using OnboardingTool.Services;
using System.Net;

namespace OnboardingTool.Controllers
{
    [Route("api/")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private static User users = new User();
        private static User_course user_courses = new User_course();
        private I_LoginValidation _loginService;
        private I_User _userService;
        private I_Course _courseService;
        private I_Buddy _buddyService;
        private I_Feedback _feedbackService;
        private I_Report _reportService;
        private I_Question _questionService;

        public UserController(I_LoginValidation loginService, I_User UserService, I_Course CourseService, I_Buddy BuddyService, I_Feedback FeedbackService,
            I_Report ReportService, I_Question QuestionService)
        {
            _loginService = loginService;
            _userService = UserService;
            _courseService = CourseService;
            _buddyService = BuddyService;
            _feedbackService = FeedbackService;
            _reportService = ReportService;
            _questionService = QuestionService;
        }

        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]

        //delete user
        [HttpDelete("/DeleteUser")]
        public string removeUser(int id)
        {
            return _userService.removeUser(id);
        }

        //add new user
        [HttpPost("/addUser")]
        public ActionResult<User> AddUser(User user)
        {
            var x = _userService.AddUser(user);
            return Ok(x);
        }

        //Validate Login
        [HttpGet("/ValidateUser")]
        public User Login_Validation(string email, string password)
        {
            var user = _loginService.Login_Validation(email, password);
            return user;
        }

        //update user info
        [HttpPut("/UpdateUser")]
        public string updateUser([FromBody] User user)
        {
            return _userService.updateUser(user);
        }

        //see feedbacks
        [HttpGet("/ShowFeedbacks")]
        public List<Feedback> showFeedback()
        {
            return _feedbackService.showFeedback();
        }

        [HttpPut("/UpdateBuddy")]
        public string updateBuddy(int id)
        {
            return (_buddyService.updateBuddy(id));
        }

        [HttpGet("/ViewBuddies")]
        public List<User> viewBuddy()
        {
            return _buddyService.viewBuddy();
        }

        //Assign Buddy
        [HttpPost("/AssignBuddy")]
        public string assignBuddy(int eId, int bId)
        {
            return _buddyService.assignBuddy(eId, bId);
        }

        //give feedback 
        [HttpPost("/GiveFeedback")]
        public string giveFeedback(string comment, int value, int ID)
        {
            return _feedbackService.addFeedback(comment, value, ID);

        }


        [HttpPut("/PromoteManager")]
        public string PromoteManager(int id)
        {
            return _userService.PromoteManager(id);
        }

        [HttpGet("/GetUser")]
        public User GetUser(int id)
        {
            return _userService.GetUser(id);
        }

        [HttpGet("/GetEmployees")]
        public List<User> GetEmployees()
        {
            return _userService.GetEmployees();
        }
        [HttpGet("/GetNewEmployees")]
        public List<User> GetNewEmployees()
        {
            return _userService.GetNewEmployees();
        }
        [HttpGet("/GetFreeNewEmployees")]
        public List<User> GetFreeNewEmployees()
        {
            return (_userService.GetFreeNewEmployees());    
        }
        //[HttpPut("/downgradeManger")]
        //public User? downgradeManger(int id, string email)
        //{
        //    return _userService.downgradeManger(id, email);
        //}

        //[HttpGet("/showBuddyRelation")]
        //public User showBuddyRelation(int id)
        //{
        //    return _userService.showBuddyRelation(id);
        //}

        [HttpGet("/CheckBuddy")]
        public string CheckBuddies(int bid)
        {
            return _buddyService.CheckBuddies(bid);
        }

        [HttpGet("/showRelationshipOfUsers")]
        public List<List<string>> relationOfUsers()
        {
            return _userService.relationOfUsers();
        }
        
        [HttpGet("/GetManagers")]
        public List<User> GetManager()
        {
            return _userService.GetManager();
        }

        [HttpGet("/viewBuddy'sEmployee")]
        public List<User> viewNewEmployeeOfBuddy(int id)
        {
            return _buddyService.viewNewEmployeeOfBuddy(id);

        }
    }
}
