﻿using BoardingSystem.Interfaces;
using Microsoft.AspNetCore.Mvc;
using OnboardingTool.Data;
using OnboardingTool.Interfaces;
using OnboardingTool.Models.Domain;
using OnboardingTool.Services;
using System.Runtime.CompilerServices;

namespace OnboardingTool.Controllers
{
    [Route("api/")]
    [ApiController]
    public class FAQController : ControllerBase
    {

        private I_FAQ _FAQService;

        public FAQController(OnBoardingContext db, I_FAQ FAQService)
        {
            _FAQService = FAQService;
        }


        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]


        [HttpPost("/addFAQ")]
        public string addFAQ(string Question, string Answer)
        {
            return (_FAQService.addFAQ(Question,Answer));
        }

        [HttpGet("/showFAQ")]
        public List<FAQ> seeFAQ()
        {
            return (_FAQService.seeFAQ());
        }
    }
}