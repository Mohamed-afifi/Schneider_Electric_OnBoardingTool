﻿namespace OnboardingTool.Controllers
{
    public class DepartmentController
    {


    }
}
