﻿using System.Collections.Generic;
using BoardingSystem.Interfaces;
using Microsoft.AspNetCore.Mvc;
using OnboardingTool.Data;
using OnboardingTool.Models.Domain;
using OnboardingTool.Services;

namespace OnboardingTool.Controllers
{
    [Route("api/")]
    [ApiController]
    public class CourseController : ControllerBase
    {
     
        private I_Course _courseService;

        public CourseController(OnBoardingContext db, I_Course CourseService)
        {
            _courseService = CourseService;
        }

        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]

        [HttpPost("/assignCourse")]
        public ActionResult<User_course> assignCourse(User_course course)
        {
            var x = _courseService.assignCourse(course);
            return Ok(x);
        }

        [HttpGet("/ShowCourses")]
        public List<Course> showCourses()
        {
            return _courseService.showCourses();
        }

        [HttpGet("/showUserCourses")]
        public List<Course> seeUserCourses(int userId)
        {
            return _courseService.seeUserCourses(userId);
        }

        [HttpGet("/ShowLectures")]
        public KeyValuePair<Course, List<Lecture>> showLectures(int CourseId)
        {
           return _courseService.showLectures(CourseId);
        }

        [HttpGet("/ShowCourse")]
        public Course showCourse(int CourseId)
        {
            return _courseService.showCourse(CourseId);
        }
    }
}