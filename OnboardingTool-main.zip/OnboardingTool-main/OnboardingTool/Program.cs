using BoardingSystem.Interfaces;
using Microsoft.EntityFrameworkCore;
using OnboardingTool.Data;
using Microsoft.OpenApi.Models;
using OnboardingTool.Services;
using OnboardingTool.Interfaces;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
builder.Services.AddTransient<I_Course, CourseService>();
builder.Services.AddTransient<I_LoginValidation,LoginService>();
builder.Services.AddScoped<I_User, UserService>();
builder.Services.AddTransient<I_Buddy, BuddyService >();
builder.Services.AddTransient<I_Feedback, FeedbackService >();
builder.Services.AddTransient<I_Report, ReportService>();
builder.Services.AddTransient<I_Question, QuestionService>();
builder.Services.AddTransient<I_FAQ, FAQService>();
builder.Services.AddTransient<I_Resources, ResourcesService>();

builder.Services.AddDbContext<OnBoardingContext>(options =>
options.UseSqlServer(builder.Configuration.GetConnectionString("OnboardingSystemConnectionString")));
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

//Enable CORS
app.UseCors(c => c.AllowAnyHeader().AllowAnyOrigin().AllowAnyMethod());

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
