﻿using Microsoft.EntityFrameworkCore;
using OnboardingTool.Data;
using OnboardingTool.Interfaces;
using OnboardingTool.Models.Domain;

namespace OnboardingTool.Services
{
    public class FeedbackService : I_Feedback
    {
        private readonly OnBoardingContext _context;

        public FeedbackService(OnBoardingContext context)
        {
            _context = context;
        }

        /// <summary>
        /// The user enters their feedback , their rate ,and their id. 
        /// </summary>
        /// <param name="comment"></param>
        /// <param name="value"></param>
        /// <param name="ID"></param>
        /// <returns></returns>
        public string addFeedback(string comment, int value, int ID)
        {
            var user = _context.User.FirstOrDefault(u => u.UserId == ID);
            if (user == null)
                return "ID is not found ";

            if (value > 0 && value <= 10)
            {
                Feedback feedback = new();
                DateTime dateTime = DateTime.Now;
                feedback.FeedbackDate = dateTime;
                feedback.FeedbackComment = comment;
                feedback.FeedbackValue = value;
                feedback.UserId = ID;
                _context.Feedback.Add(feedback);
                _context.SaveChanges();
                return "Comment added successfully ";
            }
            else
                return "Values are out of range please enter a valid rating. ";
        }

        /// <summary>
        /// Return a list of feedbacks
        /// </summary>
        /// <returns></returns>
        public List<Feedback> showFeedback()
        {
            return _context.Feedback.ToList();
        }
    }
}
