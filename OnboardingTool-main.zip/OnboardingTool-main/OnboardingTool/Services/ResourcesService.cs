﻿using Microsoft.EntityFrameworkCore;
using OnboardingTool.Data;
using OnboardingTool.Interfaces;
using OnboardingTool.Models.Domain;

namespace OnboardingTool.Services
{
    public class ResourcesService:I_Resources
    {
        private readonly OnBoardingContext _context;
        public ResourcesService(OnBoardingContext context)
        {
            _context = context;
            _context.ChangeTracker.QueryTrackingBehavior = QueryTrackingBehavior.NoTracking;
        }
        
        /// <summary>
        /// this function returns a list of the contact info
        /// </summary>
        /// <returns></returns>
        public List<Resources> viewContactInfo()
        {
            return _context.Resources.ToList();
        }

        /// <summary>
        /// this function allows th user to add resources for contact
        /// </summary>
        /// <param name="contactInfo"></param>
        /// <param name="companyPolicy"></param>
        /// <param name="usefulLink"></param>
        /// <returns></returns>
        public string addResource(string contactInfo, string companyPolicy,string usefulLink)
        {
            Resources resources = new();
            resources.ContactInfo = contactInfo;
            resources.CompanyPolicy = companyPolicy;
            resources.UsefulLink = usefulLink;
            _context.Resources.Add(resources);
            _context.SaveChanges();
            return "Resource added successfully ";
        }
    }
}
