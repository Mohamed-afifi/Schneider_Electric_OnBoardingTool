﻿using BoardingSystem.Interfaces;
using Microsoft.EntityFrameworkCore;
using OnboardingTool.Data;
using OnboardingTool.Models.Domain;
using System.Runtime.CompilerServices;

namespace OnboardingTool.Services
{
    public class UserService : I_User
    {
        private readonly OnBoardingContext _context;
 
        public UserService(OnBoardingContext context)
        {
            _context = context;
            _context.ChangeTracker.QueryTrackingBehavior = QueryTrackingBehavior.NoTracking;
        }
        
        /// <summary>
        /// Add a new user in the database
        /// </summary>
        /// <param name="user"></param>
        /// <returns>A string for each case (success, and when it already exists)</returns>
        public string AddUser(User user)
        { 
            var entity = _context.User.FirstOrDefault(u => u.email == user.email);
            if (entity != null)
            {
                return "User already exists";
            }          
            if (user.RoleId == 4)
            {
                entity.FirsttimeLogin = true;
            }
            else
            {
                user.FirsttimeLogin = false;
            }
            string userPassword = user.password;
            string salt = BCrypt.Net.BCrypt.GenerateSalt();
            user.password = BCrypt.Net.BCrypt.HashPassword(userPassword, salt);
            var userAdded = _context.User.Add(user).Entity;
            _context.SaveChanges();
            return "User added successfuly";
        }

        /// <summary>
        /// Delete a user from the database
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public string removeUser(int id)
        {
            var user = _context.User.FirstOrDefault(u => u.UserId == id);
            if (user == null)
                return "User not found";
            _context.User.Remove(user);
            _context.SaveChanges();
            return "User is removed";
        }

         /// <summary>
         /// Update all the details of the user   
         /// </summary>
         /// <param name="user"></param>
         /// <returns></returns>
        public string updateUser(User user)
        {
            if (_context.User.FirstOrDefault(u => u.UserId == user.UserId) == null)
                return "There is no user exists with this ID ";
            if (user == null)
                return "User not found";
            _context.User.Update(user);
            _context.SaveChanges();
            return "User is Updated";
        }

        /// <summary>
        /// the function promotes the manager to an admin 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public string PromoteManager(int id)
        {
            var user = _context.User.FirstOrDefault(u => u.UserId == id);
            if (user == null)
                return "ID is not found.";
            if (user.RoleId == 2 && user.job_title == "Manager")
            {
                user.RoleId = 1;
                user.job_title = "Admin";
                _context.User.Update(user);
                _context.SaveChanges();
                return "Manager is now promoted to admin.";
            }
            return "User is not a manager.";
        }

        /// <summary>
        /// this function downgrades the manager from admin back to manager 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="email"></param>
        /// <returns></returns>
        public User? downgradeManger(int id, string email)
        {
            var user = _context.User.FirstOrDefault(u => u.UserId == id);
            if (user == null)
                return user;
            if (user.RoleId == 3 && user.job_title == "Admin")
            {
                user.RoleId = 1;
                user.job_title = "Manager";
                _context.Update(user);
                _context.SaveChanges();
                return user;
            }
            return user;
        }
        
        /// <summary>
        /// this function returns each buddy with their employee
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public User? showBuddyRelation(int id)
        {
            var user = _context.User.FirstOrDefault(u => u.UserId == id);
            if (user == null)
                return user;
            if (user.RoleId == 4 && user.job_title == "NewEmployee")
            {
                var manger = _context.User.FirstOrDefault(m => m.UserId == user.buddyId);
                if (manger == null)
                {
                    return null;
                }
                return  manger;
            }
            return null;
        }

        /// <summary>
        /// Entering a user id , it return the user details
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public User GetUser(int id)
        {
            var user = _context.User.FirstOrDefault(u => u.UserId == id);
            if (user == null)
                return null;
            return user;
        }
        
        /// <summary>
        /// list of relationship between users 
        /// </summary>
        /// <returns>a list of the user relations for employees and buddies</returns>
        public List<List<string>> relationOfUsers()
        {
            List<List<string>> allusers = new List<List<string>>();
            var users = _context.User.ToList(); // Fetch all users into memory

            foreach (var i in users)
            {
                if (i.RoleId == 4 || i.RoleId ==3)
                {
                    if(i.buddyId != 0)
                    {
                        var manager = _context.User.FirstOrDefault(m => m.UserId == i.buddyId);

                        if (manager != null)
                        {
                            // Get start date from user
                            DateTime startDateTime = i.enrollment_date;
                            DateOnly startDateOnly = DateOnly.FromDateTime(startDateTime);

                            // Calculate end date for employee
                            DateOnly endDateOnly = startDateOnly.AddMonths(3);

                            // Convert dates to string
                            string stringStartDate = startDateOnly.ToString();
                            string stringEndDate = endDateOnly.ToString();

                            List<string> relation = new List<string>();
                            relation.Add(i.Name);
                            relation.Add(manager.Name);
                            relation.Add(stringStartDate);
                            relation.Add(stringEndDate);

                            allusers.Add(relation);
                        }
                    }
                }
            }
            return allusers;
        }

        /// <summary>
        /// this function gets all employees (old ones)
        /// </summary>
        /// <returns></returns>
        public List<User> GetEmployees()
        {
            return _context.User.Where(u=>u.RoleId == 3).ToList();
        }

        /// <summary>
        /// this function gets all new employees 
        /// </summary>
        /// <returns></returns>
        public List<User> GetNewEmployees()
        {
            return _context.User.Where(u => u.RoleId == 4).ToList();
        }
        
        /// <summary>
        /// this function gets new employees that don't have buddies
        /// </summary>
        /// <returns></returns>
        public List<User> GetFreeNewEmployees()
        {
            var user = _context.User.Where(u => u.RoleId == 4 && u.buddyId == 0).ToList();

            return user;
        }
        
        /// <summary>
        /// this function gets all users with the role manager
        /// </summary>
        /// <returns></returns>
        public List<User> GetManager()
        {
            List<User> Managers = new List<User>();
            
            foreach(var manager in _context.User)
            {
                if(manager.RoleId == 2)
                {
                    Managers.Add(manager);
                }
            }
            return Managers;
        }
    }
}
