﻿
using Microsoft.EntityFrameworkCore;
using OnboardingTool.Data;
using OnboardingTool.Interfaces;
using OnboardingTool.Models.Domain;

namespace OnboardingTool.Services
{
    public class ReportService : I_Report
    {
        private readonly OnBoardingContext _context;

        public ReportService(OnBoardingContext context)
        {
            _context = context;
            _context.ChangeTracker.QueryTrackingBehavior = QueryTrackingBehavior.NoTracking;
        }

        /// <summary>
        /// Return a string shows UserId , UserName , CourseName when entering their id
        /// </summary>
        /// <param name="eid"></param>
        /// <param name="cid"></param>
        public string Report(int eid,int cid)
        {
            var UserDetails = _context.User.FirstOrDefault(e => e.UserId == eid);
            var CourseDetails = _context.User_Course.FirstOrDefault(c => c.UserId == eid);
    
            var CourseName = _context.Course.FirstOrDefault(c => c.CourseId == cid);

            if (UserDetails != null && CourseDetails != null)
            {
                return "UserId: " + CourseDetails.UserId + "\n" + "User Name: " + UserDetails.Name + "\n"
                     + "\n" + "Course Name: " + CourseName.CourseName;
            }
            
            else if (UserDetails != null && CourseDetails == null)
            {
                return "User is not assigned to any courses.";
            }
            else if (CourseName == null)
            {
                return "Course id is not found";
            }
            else  if(UserDetails == null)
            {
                return "User is not found";
            }
            return "0";
        }

        /// <summary>
        /// this function allows the user to report a problem
        /// </summary>
        /// <param name="eid"></param>
        /// <param name="pDescription"></param>
        /// <returns>a string if successfull</returns>
        public string reportProblem(int eid, string pDescription)
        {
            Report report = new Report();
            report.UserId = eid;
            report.Description = pDescription;
            _context.Reports.Add(report);           
            _context.SaveChanges();
            return "Report Added Successfully";
        }
        /// <summary>
        /// this function returns all reported problems 
        /// </summary>
        /// <returns></returns>
        public List<Report> showReportproblem()
        {
            return _context.Reports.ToList();
        }

    }
}
