﻿using BoardingSystem.Interfaces;
using Microsoft.EntityFrameworkCore;
using OnboardingTool.Data;
using OnboardingTool.Interfaces;
using OnboardingTool.Models.Domain;

namespace OnboardingTool.Services
{
    public class FAQService: I_FAQ
    {
        private readonly OnBoardingContext _context;
        public FAQService(OnBoardingContext context)
        {
            _context = context;
            _context.ChangeTracker.QueryTrackingBehavior = QueryTrackingBehavior.NoTracking;
        }


        /// <summary>
        /// Adding the most frequent questions with their answers
        /// </summary>
        /// <param name="Question"></param>
        /// <param name="Answer"></param>
        /// <returns></returns>
        public string addFAQ(string Question,string Answer)
        {


            FAQ givenFAQ = new();
            //givenFAQ.QuestionId = id;
            givenFAQ.Question = Question;
            givenFAQ.Answer = Answer;
            var sameQ = _context.FAQ.FirstOrDefault(u => u.Question == Question);
            if (sameQ != null) { return "Question is already added "; }
            _context.FAQ.Add(givenFAQ);
            _context.SaveChanges();
            return "FAQ was added successfully";
        }


        /// <summary>
        /// Return a list of FAQs
        /// </summary>
        /// <returns></returns>
        public List<FAQ> seeFAQ()
        {
            return _context.FAQ.ToList();
        }

    }
}
