﻿using BoardingSystem.Interfaces;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using OnboardingTool.Data;
using OnboardingTool.Models.Domain;
using System.Data;

namespace OnboardingTool.Services
{

    public class LoginService : I_LoginValidation
    {
        private readonly OnBoardingContext _context;

        public LoginService(OnBoardingContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Check if the email and password are correct
        /// </summary>
        /// <param name="email"></param>
        /// <param name="password"></param>
        /// <returns>the user if found</returns>
        public  User? Login_Validation(string email, string password)
        {
            var user = new User();
            user = _context.User.FirstOrDefault(e => e.email == email);
            if(user == null) { return null; }
            bool isMatch = BCrypt.Net.BCrypt.Verify(password, user.password);
            if (isMatch)
                return user;
            else
                return null;
        }
    }
}

