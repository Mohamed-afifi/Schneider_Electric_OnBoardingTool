﻿using System.Collections.Generic;
using BoardingSystem.Interfaces;
using Microsoft.EntityFrameworkCore;
using OnboardingTool.Data;
using OnboardingTool.Models.Domain;

namespace OnboardingTool.Services
{
    public struct LectCourses
    {
        public List<Lecture> lectures;
        public Course course;

        public LectCourses(List<Lecture> lec, Course cour)
        {
            lectures = lec;
            course = cour;
        }
    };
    public class CourseService :  I_Course
    {
        private readonly OnBoardingContext _context;

        public CourseService(OnBoardingContext context)
        {
            _context = context;
            _context.ChangeTracker.QueryTrackingBehavior = QueryTrackingBehavior.NoTracking;
        }


        /// <summary>
        /// Assign the required courses for the employee
        /// </summary>
        /// <param name="userCourse"></param>
        /// <returns>a string that explains the status</returns>
        public string assignCourse(User_course userCourse)
        {
            var courseLen = _context.Course.ToList().Count();
            var userLen = _context.User.ToList().Count();
            var entity = _context.User_Course.FirstOrDefault(u => u.CourseId == userCourse.CourseId && u.UserId == userCourse.UserId);


            if (!(userCourse.CourseId >= 1 && userCourse.CourseId <= courseLen))
                return "Course not found";

            if (!(userCourse.UserId >= 1 && userCourse.UserId <= userLen))
                return "User not found";

            if (entity != null)
                return "This course is already assigned to this user";

            var courseAssigned = _context.User_Course.Add(userCourse).Entity;
            _context.SaveChanges();
            return "Course is assigned successfully";

        }


        public Course takeCourse(Course course)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Deleting a course
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public string deleteCourse(int id)
        {
            var course = _context.Course.Find(id);
            if (course == null)
                return "Course not found";
            _context.Course.Remove(course);
            removeAssigned(id);
            removeLectures(id);
            _context.SaveChanges();
            return "Course is removed";
            
        }

        /// <summary>
        /// Remove the users assigned to this course
        /// </summary>
        /// <param name="Course_id"></param>
        public void removeAssigned(int Course_id)
        {
            var course = _context.User_Course.FromSql($"DELETE * FROM [User_course] WHERE CourseId  = {Course_id}");
        }

        /// <summary>
        /// Remove a lecture from a course
        /// </summary>
        /// <param name="Course_id"></param>
        public void removeLectures(int Course_id)
        {
            var lecture = _context.lecture.FromSql($"DELETE * FROM [Lecture] WHERE CourseId  = {Course_id}");
        }

        /// <summary>
        /// Add course to the list of courses
        /// </summary>
        /// <param name="course"></param>
        /// <returns></returns>
        public Course addCourse(Course course)
        {
            var courseAdded = _context.Course.Add(course).Entity;
            _context.SaveChanges();

            return courseAdded;

        }

        /// <summary>
        /// this function updates the details of the course
        /// </summary>
        /// <param name="course"></param>
        /// <returns></returns>
        public string updateCourse(Course course)
        {
            var course2 = _context.Course.FirstOrDefault(m => m.CourseId == course.CourseId);
            if (course == null)
                return "Course not found";
            if (course.CourseName == "string")
            {
                course.CourseName = course2.CourseName;
            }
            if (course.Description == "string")
            {
                course.Description = course2.Description;
            }
            _context.Course.Update(course);
            _context.SaveChanges();
            return "Course is Updated";
        }

        /// <summary>
        /// Return a list of all courses
        /// </summary>
        /// <returns></returns>
        public List<Course> showCourses()
        {
            return _context.Course.ToList();
        }


        /// <summary>
        /// By entering the user id , the user is allowed to see their courses
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public List<Course> seeUserCourses(int userId)
        {
            // List courses = new List();
            var courseIds = _context.User_Course.Where(r => r.UserId == userId).Select(u => u.CourseId).ToList();
            var course = new List<Course>();
            if (courseIds != null)
            {
                course = _context.Course.Where(l => courseIds.Contains(l.CourseId)).ToList();
            }
            return course;
        }

        /// <summary>
        /// this function shows the selected course according to the id
        /// </summary>
        /// <param name="CourseId"></param>
        /// <returns>a course</returns>
        public Course? showCourse(int CourseId)
        {
            var course = _context.Course.FirstOrDefault(m => m.CourseId == CourseId);
            if (course == null) return null;
            return (Course)course;
        }

        /// <summary>
        /// shows the details of a course with its lectures
        /// </summary>
        /// <param name="CourseId"></param>
        /// <returns>a list that conatins each the course and the lectures of this course</returns>
        public KeyValuePair<Course, List<Lecture>> showLectures(int CourseId)
        {
            var course = _context.Course.FirstOrDefault(r => r.CourseId == CourseId); 
            var lectures = _context.lecture.Where(r => r.CourseId == CourseId).ToList();
            KeyValuePair<Course, List<Lecture>> courseLectures1 = new KeyValuePair<Course, List<Lecture>>(
            course, lectures);
            return courseLectures1;
        }
    }
}

    


