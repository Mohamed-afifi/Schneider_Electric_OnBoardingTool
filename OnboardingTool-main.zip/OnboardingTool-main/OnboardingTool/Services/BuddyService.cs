﻿using BoardingSystem.Interfaces;
using Microsoft.EntityFrameworkCore;
using OnboardingTool.Data;
using OnboardingTool.Models.Domain;
using System.Diagnostics.CodeAnalysis;
using OnboardingTool.Services;

namespace OnboardingTool.Services
{
    public class BuddyService : I_Buddy 
    {

        private readonly OnBoardingContext _context;

        public BuddyService(OnBoardingContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Show all buddies in the system
        /// </summary>
        /// <returns>a list of buddies</returns>
        public List<User> viewBuddy()
        {
            List<User> buddies = new List<User>();
            foreach (var user in _context.User)
            {
                if (user.RoleId == 2 && user.is_buddy)
                {
                    buddies.Add(user);

                }

            }
            return buddies;
        }

        /// Assign a buddy to an employee
        /// <param name="eId"></param>
        /// <param name="bId"></param>
        public string assignBuddy(int eId, int bId)
        {
            var emp = _context.User.FirstOrDefault(e => e.UserId == eId);
            var buddy = _context.User.FirstOrDefault(b => b.UserId == bId);

            if(emp == null)
            {
                return "Employee ID is not found. ";
            }
            if(buddy == null)
            {
                return "Buddy ID is not found. ";
            }
            if(emp.RoleId == 3 || emp.RoleId == 4)
            {
                if (emp.buddyId == 0 && buddy.is_buddy == true && !emp.is_buddy)
                {
                    emp.buddyId = bId;
                    _context.Update(emp);
                    _context.SaveChanges();
                    return "Buddy: " + bId + " is assigned to Employee: " + eId;
                }
            }
            if (eId == bId)
            {
                return "Can not enter the same Buddy ID as the Employee ID. ";
            }
            if (emp.buddyId != 0)
            {
                return " This employee is already assigned to a buddy. ";
            }
            if (buddy.is_buddy == false)
            {
                return "This ID is not a buddy.";
            }

            return "User is not an employee";
        }

        /// <summary>
        /// Admin chooses a manager to become a buddy
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public string updateBuddy(int id)
        {
            var manager = _context.User.FirstOrDefault(m => m.UserId == id);
            if (manager == null)
            {

                return "Id is not found";
            }

            if ((manager.RoleId == 2|| manager.RoleId == 3) && !manager.is_buddy)
            {
                manager.is_buddy = true;
                _context.SaveChanges();
                return "This Manager is now a Buddy";
            }
            else if ((manager.RoleId == 2 || manager.RoleId == 3) && manager.is_buddy)
            {
                manager.is_buddy = false;
                _context.SaveChanges();
                return "This Manager is now not a Buddy";
            }
            else if (manager.RoleId != 2)
            {
                _context.SaveChanges();
                return "This user is not a Manager";
            }

            return "0";
        }

        /// <summary>
        /// Check if a buddy is assign to an employee or not
        /// </summary>
        /// <param name="bid"></param>
        /// <returns></returns>
        public string CheckBuddies(int bid)
        {
            var buddy = _context.User.FirstOrDefault(u => u.UserId == bid);
            var buddyId = _context.User.FirstOrDefault(b => b.buddyId == bid);

            if (buddy == null)
            {
                return "ID is not found";
            }
            if (buddy != null)
            {
                if (buddy.is_buddy)
                {
                    if (buddyId != null)
                    {
                        return "This buddy is assigned to an employee";
                    }
                    else
                    {
                        return "Buddy is not assigned to any employees";
                    }
                }
                else
                {
                    return "User is not a buddy";
                }
            }
            return "0";
        }

        /// <summary>
        /// this function returns a list of employees that are assigned to a specific employee
        /// </summary>
        /// <param name="MangerId"></param>
        /// <returns>list of new employees</returns>
        public List<User> viewNewEmployeeOfBuddy(int MangerId)
        {
            var newEmployee = new List<User>();
            var entity = _context.User.ToList();
            
            foreach (var user in entity)
            {
                if (user.is_buddy==false)
                {
                    return null;
                }
                if (user.buddyId == MangerId)
                {
                    newEmployee.Add(user);
                }
            }
            return newEmployee;
        }
    }
}

