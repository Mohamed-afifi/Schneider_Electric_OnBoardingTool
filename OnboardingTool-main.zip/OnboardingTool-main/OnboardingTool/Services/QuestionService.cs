﻿using BoardingSystem.Interfaces;
using Microsoft.EntityFrameworkCore;
using OnboardingTool.Data;
using OnboardingTool.Interfaces;
using OnboardingTool.Models.Domain;

namespace OnboardingTool.Services
{
    public class QuestionService : I_Question
    {
        private readonly OnBoardingContext _context;

        public QuestionService(OnBoardingContext context)
        {
            _context = context;
            _context.ChangeTracker.QueryTrackingBehavior = QueryTrackingBehavior.NoTracking;
        }

        /// <summary>
        /// Return a list of 10 random distinct questions
        /// </summary>
        /// <param name="courseId"></param>
        public List<Question> GetRandomQuestions(int courseId)
        {
            var random = new Random();
            var questionsForCourse = _context.Question
                .Where(q => q.CourseId == courseId)
                .ToList();
            if (questionsForCourse.Count < 10)
            {
                return null; 
            }
            var shuffledQuestions = questionsForCourse.OrderBy(q => random.Next()).ToList(); //return randomized questions
            var distinctRandomQuestions = shuffledQuestions.Distinct().Take(10).ToList(); //return 10 distinct questions
            return distinctRandomQuestions;
        }
    }
}
