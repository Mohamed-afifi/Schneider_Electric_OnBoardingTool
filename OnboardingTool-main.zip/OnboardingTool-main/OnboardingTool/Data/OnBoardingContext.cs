﻿using Microsoft.EntityFrameworkCore;
//using Microsoft.AspNetCore.Authorization.Infrastructure;
//using System.Reflection.PortableExecutable;
using OnboardingTool.Models.Domain;
using System.Numerics;
using static System.Net.WebRequestMethods;

namespace OnboardingTool.Data
{
    public class OnBoardingContext : DbContext
    {
        public OnBoardingContext(DbContextOptions options) : base(options)
        {
        }

        public DbSet<User> User { get; set; }
        public DbSet<Course> Course { get; set; }
        public DbSet<User_course> User_Course { get; set; }
        public DbSet<Role> Role { get; set; }
        public DbSet<log> log { get; set; }
        public DbSet<Lecture> lecture { get; set; }
        public DbSet<Feedback> Feedback { get; set; }
        public DbSet<Question> Question { get; set; }
        public DbSet<FAQ> FAQ { get; set; }
        public DbSet<Departments> Departments { get; set; }
        public DbSet<Resources> Resources { get; set; }
        public DbSet<Report> Reports { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {



            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<User>().HasKey(c => c.UserId);
            modelBuilder.Entity<Role>().HasKey(c => c.RoleId);
            modelBuilder.Entity<Course>().HasKey(c => c.CourseId);
            modelBuilder.Entity<User_course>().HasKey(c => new { c.CourseId, c.UserId });
            modelBuilder.Entity<log>().HasKey(c => c.Id);
            modelBuilder.Entity<Lecture>().HasKey(c => c.LectureId);
            modelBuilder.Entity<Feedback>().HasKey(c => c.FeedbackId);
            modelBuilder.Entity<Question>().HasKey(c => c.QuestionId);
            modelBuilder.Entity<FAQ>().HasKey(c => c.QuestionId);
            modelBuilder.Entity<Departments>().HasNoKey();
            modelBuilder.Entity<Resources>().HasKey(c => c.ResourceID);
            modelBuilder.Entity<Report>().HasKey(c => c.ReportId);

            modelBuilder.Entity<Lecture>()
            .HasOne(l => l.Course)
            .WithMany(c => c.Lectures)
            .HasForeignKey(l => l.CourseId);

            modelBuilder.Entity<Question>()
            .HasOne(l => l.Course)
            .WithMany(c => c.Questions)
            .HasForeignKey(l => l.CourseId);

            // Employers

            // Admins                        
            modelBuilder.Entity<User>().HasData(new User { UserId = 1, Name = "Tarek Sherif", age = 35, email = "Tareksh@SE.com", phoneNum = 123010010, job_title = "Admin", RoleId = 1, is_buddy = false, buddyId = 0, enrollment_date = new DateTime(2014, 3, 1, 8, 0, 0), password = "TarekSE1", FirsttimeLogin = false, new_employee = false }); ;
            modelBuilder.Entity<User>().HasData(new User { UserId = 2, Name = "Mostafa Hosny", age = 34, email = "Mostafa@SE.com", phoneNum = 123456123, job_title = "Admin", RoleId = 1, is_buddy = false, buddyId = 0, enrollment_date = new DateTime(2015, 9, 7, 8, 0, 0), password = "MostafaH15", FirsttimeLogin = false, new_employee = false });
            modelBuilder.Entity<User>().HasData(new User { UserId = 24, Name = "Eng. Zezo", age = 22, email = "Zezo@SE.com", phoneNum = 118463323, job_title = "Admin", RoleId = 1, is_buddy = false, buddyId = 0, enrollment_date = new DateTime(2023, 9, 7, 8, 0, 0), password = "Zezo22312", FirsttimeLogin = false, new_employee = false });

            //   Managers
            modelBuilder.Entity<User>().HasData(new User { UserId = 32, Name = "Ali Hamada", age = 20, email = "Alihamada@SE.com", phoneNum = 44115572, job_title = "Manager", RoleId = 2, is_buddy = true, buddyId = 0, enrollment_date = new DateTime(2023, 9, 7, 8, 0, 0), password = "HanaA10", FirsttimeLogin = false, new_employee = true });
            modelBuilder.Entity<User>().HasData(new User { UserId = 38, Name = "Mohamed Afifi", age = 240, email = "MohAfifi@SE.com", phoneNum = 56153121, job_title = "Manager", RoleId = 2, is_buddy = true, buddyId = 0, enrollment_date = new DateTime(2023, 9, 7, 8, 0, 0), password = "MohAfifi@Schneider.com", FirsttimeLogin = false, new_employee = false });
            modelBuilder.Entity<User>().HasData(new User { UserId = 45, Name = "Habiba Mohamed", age = 22, email = "HabibaM@SE.com", phoneNum = 65656554, job_title = "Manager", RoleId = 2, is_buddy = true, buddyId = 0, enrollment_date = new DateTime(2023, 9, 7, 8, 0, 0), password = "Youssef10", FirsttimeLogin = false, new_employee = true });
            modelBuilder.Entity<User>().HasData(new User { UserId = 3, Name = "Hamza Hussein", age = 28, email = "HamzaHuss@SE.com", phoneNum = 101001010, job_title = "Manager", RoleId = 2, is_buddy = true, buddyId = 0, enrollment_date = new DateTime(2017, 1, 1, 8, 0, 0), password = "Tarek10", FirsttimeLogin = false, new_employee = false });
            modelBuilder.Entity<User>().HasData(new User { UserId = 4, Name = "Ahmad Mohamed", age = 28, email = "Ahmad@SE.com", phoneNum = 101001010, job_title = "Manager", RoleId = 2, is_buddy = true, buddyId = 0, enrollment_date = new DateTime(2019, 9, 7, 8, 0, 0), password = "hamada10", FirsttimeLogin = false, new_employee = false });
            modelBuilder.Entity<User>().HasData(new User { UserId = 5, Name = "Youssef Fouad", age = 27, email = "YoussefF@SE.com", phoneNum = 10245974, job_title = "Manager", RoleId = 2, is_buddy = true, buddyId = 0, enrollment_date = new DateTime(2019, 9, 7, 8, 0, 0), password = "Youssef10", FirsttimeLogin = false, new_employee = false });
            modelBuilder.Entity<User>().HasData(new User { UserId = 6, Name = "Salma Ihab", age = 24, email = "SalmaI@SE.com", phoneNum = 102557940, job_title = "Manager", RoleId = 2, is_buddy = true, buddyId = 0, enrollment_date = new DateTime(2022, 8, 15, 8, 0, 0), password = "Salma10", FirsttimeLogin = false, new_employee = false });
            modelBuilder.Entity<User>().HasData(new User { UserId = 7, Name = "Jessy Khaled", age = 26, email = "HabibaM@SE.com", phoneNum = 105886414, job_title = "Manager", RoleId = 2, is_buddy = true, buddyId = 0, enrollment_date = new DateTime(2020, 2, 7, 8, 0, 0), password = "Habiba10", FirsttimeLogin = false, new_employee = false });
            modelBuilder.Entity<User>().HasData(new User { UserId = 23, Name = "Basel Nabil", age = 21, email = "basel@SE.com", phoneNum = 118846987, job_title = "Mananger", RoleId = 2, is_buddy = true, buddyId = 0, enrollment_date = new DateTime(2019, 8, 7, 8, 0, 0), password = "bas1234", FirsttimeLogin = false, new_employee = false });



            // Employees
            modelBuilder.Entity<User>().HasData(new User { UserId = 8, Name = "Lesya Kolyada", age = 25, email = "LesyaK@SE.com", phoneNum = 1010678010, job_title = "Employee", RoleId = 3, is_buddy = false, buddyId = 6, enrollment_date = new DateTime(2023, 9, 7, 8, 0, 0), password = "Lesya10", FirsttimeLogin = true, new_employee = false });
            modelBuilder.Entity<User>().HasData(new User { UserId = 9, Name = "Homos Awadallah", age = 25, email = "homos@SE.com", phoneNum = 1010678010, job_title = "Employee", RoleId = 3, is_buddy = false, buddyId = 7, enrollment_date = new DateTime(2023, 9, 7, 8, 0, 0), password = "homos10", FirsttimeLogin = true, new_employee = true });
            modelBuilder.Entity<User>().HasData(new User { UserId = 10, Name = "Talya Hany", age = 25, email = "TalyH@SE.com", phoneNum = 1010678010, job_title = "Employee", RoleId = 3, is_buddy = false, buddyId = 0, enrollment_date = new DateTime(2023, 9, 7, 8, 0, 0), password = "Talya10", FirsttimeLogin = true, new_employee = false });
            modelBuilder.Entity<User>().HasData(new User { UserId = 11, Name = "Mohamed Hassan", age = 25, email = "MohamedH@SE.com", phoneNum = 1010678010, job_title = "Employee", RoleId = 3, is_buddy = false, buddyId = 0, enrollment_date = new DateTime(2023, 9, 7, 8, 0, 0), password = "MohamedH10", FirsttimeLogin = true, new_employee = true });
            modelBuilder.Entity<User>().HasData(new User { UserId = 12, Name = "Ahmed Mostafa", age = 24, email = "AhmedM@SE.com", phoneNum = 856745515, job_title = "Employee", RoleId = 3, is_buddy = false, buddyId = 0, enrollment_date = new DateTime(2023, 9, 7, 8, 0, 0), password = "AhmedM", FirsttimeLogin = true, new_employee = false });
            modelBuilder.Entity<User>().HasData(new User { UserId = 26, Name = "Ali Yasser", age = 20, email = "AliYasser@SE.com", phoneNum = 1225544963, job_title = "Employee", RoleId = 3, is_buddy = false, buddyId = 0, enrollment_date = new DateTime(2023, 9, 7, 8, 0, 0), password = "MostafaH445", FirsttimeLogin = true, new_employee = true });


            // New Employees
            modelBuilder.Entity<User>().HasData(new User { UserId = 13, Name = "Hana Aly", age = 26, email = "HanaA@SE.com", phoneNum = 1447894642, job_title = "New Employee", RoleId = 4, is_buddy = false, buddyId = 3, enrollment_date = new DateTime(2023, 9, 7, 8, 0, 0), password = "HanaA10", FirsttimeLogin = true, new_employee = true });
            modelBuilder.Entity<User>().HasData(new User { UserId = 14, Name = "Omar Abu Gabal", age = 25, email = "OmarAG@SE.com", phoneNum = 223474980, job_title = "New Employee", RoleId = 4, is_buddy = false, buddyId = 4, enrollment_date = new DateTime(2023, 9, 7, 8, 0, 0), password = "OmarAG10", FirsttimeLogin = true, new_employee = true });
            modelBuilder.Entity<User>().HasData(new User { UserId = 15, Name = "Youssef Hawary", age = 26, email = "YoussefH@SE.com", phoneNum = 545465456, job_title = "New Employee", RoleId = 4, is_buddy = false, buddyId = 5, enrollment_date = new DateTime(2023, 9, 7, 8, 0, 0), password = "Youssef10", FirsttimeLogin = true, new_employee = true });
            modelBuilder.Entity<User>().HasData(new User { UserId = 16, Name = "Amaal Hassan", age = 25, email = "AmaalH@SE.com", phoneNum = 101025610, job_title = "New Employee", RoleId = 4, is_buddy = false, buddyId = 6, enrollment_date = new DateTime(2023, 9, 7, 8, 0, 0), password = "AmaalH10", FirsttimeLogin = true, new_employee = true });
            modelBuilder.Entity<User>().HasData(new User { UserId = 17, Name = "Ahmed Tanbouly", age = 25, email = "AhmedT@SE.com", phoneNum = 155787618, job_title = "New Employee", RoleId = 4, is_buddy = false, buddyId = 23, enrollment_date = new DateTime(2023, 9, 7, 8, 0, 0), password = "AhmedT10", FirsttimeLogin = true, new_employee = true });
            modelBuilder.Entity<User>().HasData(new User { UserId = 18, Name = "Donia El-0Karany", age = 22, email = "Donia-K@SE.com", phoneNum = 1017745610, job_title = "New Employee", RoleId = 4, is_buddy = false, buddyId = 32, enrollment_date = new DateTime(2023, 9, 7, 8, 0, 0), password = "Donia10", FirsttimeLogin = true, new_employee = true });
            modelBuilder.Entity<User>().HasData(new User { UserId = 27, Name = "Adel Mohamed", age = 20, email = "adel@SE.com", phoneNum = 555497678, job_title = "New Employee", RoleId = 4, is_buddy = false, buddyId = 38, enrollment_date = new DateTime(2023, 9, 7, 8, 0, 0), password = "adel3321", FirsttimeLogin = true, new_employee = true });
            modelBuilder.Entity<User>().HasData(new User { UserId = 28, Name = "Youssef Seyam", age = 25, email = "YoussefSeyam@SE.com", phoneNum = 11134455, job_title = "New Employee", RoleId = 4, is_buddy = false, buddyId = 45, enrollment_date = new DateTime(2023, 9, 7, 8, 0, 0), password = "YoussefSE00929", FirsttimeLogin = true, new_employee = true });
            modelBuilder.Entity<User>().HasData(new User { UserId = 29, Name = "Afify Mohamed", age = 22, email = "afify@SE.com", phoneNum = 11544666, job_title = "New Employee", RoleId = 4, is_buddy = false, buddyId = 7, enrollment_date = new DateTime(2023, 9, 7, 8, 0, 0), password = "afify77373", FirsttimeLogin = true, new_employee = true });


            // Roles

            modelBuilder.Entity<Role>().HasData(new Role { RoleId = 1, title = "Admin", new_employee = false });
            modelBuilder.Entity<Role>().HasData(new Role { RoleId = 2, title = "Manager", new_employee = false });
            modelBuilder.Entity<Role>().HasData(new Role { RoleId = 3, title = "Employee", new_employee = false });
            modelBuilder.Entity<Role>().HasData(new Role { RoleId = 4, title = "NewEmployee", new_employee = true });

            // COURSES

            //Course 1                                                             
            modelBuilder.Entity<Course>().HasData(new Course { CourseId = 1, CourseName = "CS50", Description = "CS50x course is an introduction to the intellectual enterprises of computer science and the art of programming for majors and non-majors alike, with or without prior programming experience. An entry-level course taught by David J. Malan, CS50x teaches students how to think algorithmically and solve problems efficiently. Topics include abstraction, algorithms, data structures, encapsulation, resource management, security, software engineering, and web development. Languages include C, Python, SQL, and JavaScript plus CSS and HTML. Problem sets inspired by real-world domains of biology, cryptography, finance, forensics, and gaming." });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 1, CourseId = 1, LectureName = "Lecture1", URL = "https://www.youtube.com/embed/IDDmrzzB14M" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 2, CourseId = 1, LectureName = "Lecture2", URL = "https://www.youtube.com/embed/ywg7cW0Txs4" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 3, CourseId = 1, LectureName = "Lecture3", URL = "https://www.youtube.com/embed/XmYnsO7iSI8" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 4, CourseId = 1, LectureName = "Lecture4", URL = "https://www.youtube.com/embed/4oqjcKenCH8" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 5, CourseId = 1, LectureName = "Lecture5", URL = "https://www.youtube.com/embed/AcWIE9qazLI" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 6, CourseId = 1, LectureName = "Lecture6", URL = "https://www.youtube.com/embed/X8h4dq9Hzq8" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 7, CourseId = 1, LectureName = "Lecture7", URL = "https://www.youtube.com/embed/5Jppcxc1Qzc" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 8, CourseId = 1, LectureName = "Lecture8", URL = "https://www.youtube.com/embed/zrCLRC3Ci1c" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 9, CourseId = 1, LectureName = "Lecture9", URL = "https://www.youtube.com/embed/alnzFK-4xMY" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 10, CourseId = 1, LectureName = "Lecture10", URL = "https://www.youtube.com/embed/Kuy4cEXpXEE" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 11, CourseId = 1, LectureName = "Lecture11", URL = "https://www.youtube.com/embed/oVA0fD13NGI" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 12, CourseId = 1, LectureName = "Lecture12", URL = "https://www.youtube.com/embed/iXG0sXlzuF0" });

            //Course 2                                                             
            modelBuilder.Entity<Course>().HasData(new Course { CourseId = 2, CourseName = "Angular", Description = "This course is a comprehensive introduction to Angular, a popular open-source JavaScript framework for building single-page applications. It is designed for beginners with no prior experience with Angular or JavaScript.\r\n\r\nIn this course, you will learn the basics of Angular, including:\r\n\r\nThe Angular framework architecture\r\nComponents\r\nDirectives\r\nServices\r\nRouting\r\nForms\r\nHttp\r\nTesting\r\nYou will also learn how to build real-world Angular applications. By the end of this course, you will be able to:\r\n\r\nBuild single-page applications with Angular\r\nUse Angular components to create reusable user interface elements\r\nCreate custom directives to extend the functionality of Angular\r\nUse Angular services to access data and functionality from external sources\r\nImplement routing in your Angular applications\r\nCreate and validate forms in Angular\r\nMake HTTP requests in Angular\r\nTest your Angular applications" });

            // Lectures
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 13, CourseId = 2, LectureName = "Lecture1", URL = "https://www.youtube.com/embed/CB3XOsaTEbM" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 14, CourseId = 2, LectureName = "Lecture2", URL = "https://www.youtube.com/embed/Vgmq7rDh7a0" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 15, CourseId = 2, LectureName = "Lecture3", URL = "https://www.youtube.com/embed/Yo-P7YD0Fdo" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 16, CourseId = 2, LectureName = "Lecture4", URL = "https://www.youtube.com/embed/UyWDqZODprk" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 17, CourseId = 2, LectureName = "Lecture5", URL = "https://www.youtube.com/embed/aOB2nmuICJo" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 18, CourseId = 2, LectureName = "Lecture6", URL = "https://www.youtube.com/embed/w_57TIwRQPg" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 19, CourseId = 2, LectureName = "Lecture7", URL = "https://www.youtube.com/embed/kkLUhz9pXi0" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 20, CourseId = 2, LectureName = "Lecture8", URL = "https://www.youtube.com/embed/7gLHa_ShHWU" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 21, CourseId = 2, LectureName = "Lecture9", URL = "https://www.youtube.com/embed/zyA2zjFYC9I" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 22, CourseId = 2, LectureName = "Lecture10", URL = "https://www.youtube.com/embed/qv07isP7aZQ" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 23, CourseId = 2, LectureName = "Lecture11", URL = "https://www.youtube.com/embed/JdXJhNI43SY" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 24, CourseId = 2, LectureName = "Lecture12", URL = "https://www.youtube.com/embed/uBgptTSejD4" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 25, CourseId = 2, LectureName = "Lecture13", URL = "https://www.youtube.com/embed/5DZ6RCa6Eaw" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 26, CourseId = 2, LectureName = "Lecture14", URL = "https://www.youtube.com/embed/Z8F4_191pCU" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 27, CourseId = 2, LectureName = "Lecture15", URL = "https://www.youtube.com/embed/6gV6_TI85sk" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 28, CourseId = 2, LectureName = "Lecture16", URL = "https://www.youtube.com/embed/UIKdmGMG42U" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 29, CourseId = 2, LectureName = "Lecture17", URL = "https://www.youtube.com/embed/ELS_QdbqF_Q" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 30, CourseId = 2, LectureName = "Lecture18", URL = "https://www.youtube.com/embed/-IUDQBvtqc8" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 31, CourseId = 2, LectureName = "Lecture19", URL = "https://www.youtube.com/embed/IlxcSHCFECY" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 32, CourseId = 2, LectureName = "Lecture20", URL = "https://www.youtube.com/embed/dhN1j7ZgnAI" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 33, CourseId = 2, LectureName = "Lecture21", URL = "https://www.youtube.com/embed/wbZGVI0CSb4" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 34, CourseId = 2, LectureName = "Lecture22", URL = "https://www.youtube.com/embed/-70mkrY_Tz8" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 35, CourseId = 2, LectureName = "Lecture23", URL = "https://www.youtube.com/embed/BdZrC_RwVGU" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 36, CourseId = 2, LectureName = "Lecture24", URL = "https://www.youtube.com/embed/ja_KmhIP_M4" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 37, CourseId = 2, LectureName = "Lecture25", URL = "https://www.youtube.com/embed/ksYE8aMkp90" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 38, CourseId = 2, LectureName = "Lecture26", URL = "https://www.youtube.com/embed/PbYIOZNNZtE" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 39, CourseId = 2, LectureName = "Lecture27", URL = "https://www.youtube.com/embed/VckwZSMetRA" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 40, CourseId = 2, LectureName = "Lecture28", URL = "https://www.youtube.com/embed/t-BeD-7LU0I" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 41, CourseId = 2, LectureName = "Lecture29", URL = "https://www.youtube.com/embed/wCmnnV7DU6Q" });

            //Course 3                   CCNA                                          
            modelBuilder.Entity<Course>().HasData(new Course { CourseId = 3, CourseName = "CCNA", Description = "Begin preparing for a networking career with this introduction to how networks operate. This course of the CCNA series introduces architectures, models, protocols, and networking elements – functions needed to support the operations and priorities of Fortune 500 companies to small innovative retailers. You’ll even get the chance to build simple local area networks (LANs). Developing a working knowledge of IP addressing schemes, foundational network security, you'll be able to perform basic configurations for routers and switches. No prerequisites required. After completing all three CCNA courses, you are ready to take the CCNA Certification. \r\nYou'll Learn to build simple LANs, perform basic configurations for routers and switches, and implement IPv4 and IPv6 addressing schemes.\r\nConfigure routers, switches, and end devices to provide access to local and remote network resources and to enable end-to-end connectivity between remote devices.\r\nDevelop critical thinking and problem-solving skills using real equipment and Cisco Packet Tracer.\r\nConfigure and troubleshoot connectivity a small network using security best practices." });            // Lectures

            // Lectures

            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 42, CourseId = 3, LectureName = "Lecture1", URL = "https://www.youtube.com/embed/S7MNX_UD7vY" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 43, CourseId = 3, LectureName = "Lecture2", URL = "https://www.youtube.com/embed/9eH16Fxeb9o" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 44, CourseId = 3, LectureName = "Lecture3", URL = "https://www.youtube.com/embed/p9ScLm9S3B4" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 45, CourseId = 3, LectureName = "Lecture4", URL = "https://www.youtube.com/embed/CRdL1PcherM" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 46, CourseId = 3, LectureName = "Lecture5", URL = "https://www.youtube.com/embed/3kfO61Mensg" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 47, CourseId = 3, LectureName = "Lecture6", URL = "https://www.youtube.com/embed/oIRkXulqJA4" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 48, CourseId = 3, LectureName = "Lecture7", URL = "https://www.youtube.com/embed/xPi4uZu4uF0" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 51, CourseId = 3, LectureName = "Lecture10", URL = "https://www.youtube.com/embed/80vIin4xGp8" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 52, CourseId = 3, LectureName = "Lecture11", URL = "https://www.youtube.com/embed/37tyxaQbtN4" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 53, CourseId = 3, LectureName = "Lecture12", URL = "https://www.youtube.com/embed/y8h5qY3zwic" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 54, CourseId = 3, LectureName = "Lecture13", URL = "https://www.youtube.com/embed/MLxgmkRzgIQ" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 55, CourseId = 3, LectureName = "Lecture14", URL = "https://www.youtube.com/embed/MLxgmkRzgIQ" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 56, CourseId = 3, LectureName = "Lecture15", URL = "https://www.youtube.com/embed/E3DEJ7odWq0" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 57, CourseId = 3, LectureName = "Lecture16", URL = "https://www.youtube.com/embed/0W4JZIWtjLQ" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 58, CourseId = 3, LectureName = "Lecture17", URL = "https://www.youtube.com/embed/5WfiTHiU4x8" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 59, CourseId = 3, LectureName = "Lecture18", URL = "https://www.youtube.com/embed/tcae4TSSMo8" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 60, CourseId = 3, LectureName = "Lecture19", URL = "https://www.youtube.com/embed/8bhvn9tQk8o" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 61, CourseId = 3, LectureName = "Lecture20", URL = "https://www.youtube.com/embed/2-i5x8KCfII" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 62, CourseId = 3, LectureName = "Lecture21", URL = "https://www.youtube.com/embed/oZGZRtaGyG8" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 63, CourseId = 3, LectureName = "Lecture22", URL = "https://www.youtube.com/embed/mJ_5qeqGOaI" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 64, CourseId = 3, LectureName = "Lecture23", URL = "https://www.youtube.com/embed/B1vqKQIPxr0" });

            // Course 4 HTML, & CSS
            modelBuilder.Entity<Course>().HasData(new Course { CourseId = 4, CourseName = "HTML & CSS", Description = "This course is a comprehensive introduction to the HTML and CSS markup languages. HTML is used to create the structure of a web page, while CSS is used to style the appearance of the HTML elements. In this course, you will learn the basics of both HTML and CSS, including tags, attributes, selectors, and properties. You will also learn how to use HTML and CSS to create a variety of web pages, including simple websites, landing pages, and blog posts." });

            //Lectures
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 65, CourseId = 4, LectureName = "Lecture1", URL = "https://youtu.be/hu-q2zYwEYs" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 66, CourseId = 4, LectureName = "Lecture2", URL = "https://youtu.be/mbeT8mpmtHA" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 67, CourseId = 4, LectureName = "Lecture3", URL = "https://youtu.be/YwbIeMlxZAU" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 68, CourseId = 4, LectureName = "Lecture4", URL = "https://youtu.be/D3iEE29ZXRM" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 69, CourseId = 4, LectureName = "Lecture5", URL = "https://youtu.be/FHZn6706e3Q" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 70, CourseId = 4, LectureName = "Lecture6", URL = "https://youtu.be/kGW8Al_cga4" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 71, CourseId = 4, LectureName = "Lecture7", URL = "https://youtu.be/25R1Jl5P7Mw" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 72, CourseId = 4, LectureName = "Lecture8", URL = "https://youtu.be/XQaHAAXIVg8" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 73, CourseId = 4, LectureName = "Lecture9", URL = "https://youtu.be/FMu2cKWD90g" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 74, CourseId = 4, LectureName = "Lecture10", URL = "https://youtu.be/Xig7NsIE6DI" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 75, CourseId = 4, LectureName = "Lecture11", URL = "https://youtu.be/qES0HypsUK0" });

            //   Course 5 NODE JS
            modelBuilder.Entity<Course>().HasData(new Course { CourseId = 5, CourseName = "Node JS", Description = "This course is a comprehensive introduction to the Node.js programming language. Node.js is a popular platform for building scalable, real-time web applications. In this course, you will learn the basics of Node.js, including its event-driven architecture, its non-blocking I/O model, and its powerful ecosystem of modules. You will also learn how to build web applications with Node.js, including REST APIs, chat applications, and real-time multiplayer games." });

            // Lectures
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 76, CourseId = 5, LectureName = "Lecture1", URL = "https://youtu.be/zb3Qk8SG5Ms" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 77, CourseId = 5, LectureName = "Lecture2", URL = "https://youtu.be/OIBIXYLJjsI" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 78, CourseId = 5, LectureName = "Lecture3", URL = "https://youtu.be/-HPZ1leCV8k" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 79, CourseId = 5, LectureName = "Lecture4", URL = "https://youtu.be/DQD00NAUPNk" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 80, CourseId = 5, LectureName = "Lecture5", URL = "https://youtu.be/bdHE2wHT-gQ" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 81, CourseId = 5, LectureName = "Lecture6", URL = "https://youtu.be/Lr9WUkeYSA8" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 82, CourseId = 5, LectureName = "Lecture7", URL = "https://youtu.be/yXEesONd_54" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 83, CourseId = 5, LectureName = "Lecture8", URL = "https://youtu.be/_GJKAs7A0_4" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 84, CourseId = 5, LectureName = "Lecture9", URL = "https://youtu.be/bxsemcrY4gQ" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 85, CourseId = 5, LectureName = "Lecture10", URL = "https://youtu.be/VVGgacjzc2Y" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 86, CourseId = 5, LectureName = "Lecture11", URL = "https://youtu.be/zW_tZR0Ir3Q" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 87, CourseId = 5, LectureName = "Lecture12", URL = "https://youtu.be/nYAyhRAV87A" });

            // Course 6 TYPESCRIPT
            modelBuilder.Entity<Course>().HasData(new Course { CourseId = 6, CourseName = "TypeScript", Description = "This course is an introduction to the TypeScript programming language. TypeScript is a superset of JavaScript that adds type safety to the language. This makes it easier to write robust and maintainable code. In this course, you will learn the basics of TypeScript, including variables, functions, objects, and classes. You will also learn how to use TypeScript to build web applications and Node.js servers." });

            //Lectures 
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 88, CourseId = 6, LectureName = "Lecture1", URL = "https://youtu.be/j89BvWz8Eag" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 89, CourseId = 6, LectureName = "Lecture2", URL = "https://youtu.be/JjWRNtBorMw" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 90, CourseId = 6, LectureName = "Lecture3", URL = "https://youtu.be/kvm8tsRj6BM" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 91, CourseId = 6, LectureName = "Lecture4", URL = "https://youtu.be/kvm8tsRj6BM" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 92, CourseId = 6, LectureName = "Lecture5", URL = "https://youtu.be/JrZfUktGano" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 93, CourseId = 6, LectureName = "Lecture6", URL = "https://youtu.be/de6Q0I4yMI8" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 94, CourseId = 6, LectureName = "Lecture7", URL = "https://youtu.be/ULMH3lxygXY" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 95, CourseId = 6, LectureName = "Lecture8", URL = "https://youtu.be/tx4NHrhJK_Q" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 96, CourseId = 6, LectureName = "Lecture9", URL = "https://youtu.be/p8HML9W2F6E" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 97, CourseId = 6, LectureName = "Lecture10", URL = "https://youtu.be/Dzn5BjAcCB0" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 98, CourseId = 6, LectureName = "Lecture11", URL = "https://youtu.be/lLM6ozP8UXE" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 99, CourseId = 6, LectureName = "Lecture12", URL = "https://youtu.be/mblT909451o" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 100, CourseId = 6, LectureName = "Lecture13", URL = "https://youtu.be/ulouRaA0tHc" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 101, CourseId = 6, LectureName = "Lecture14", URL = "https://youtu.be/MMRjLubm4GY" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 102, CourseId = 6, LectureName = "Lecture15", URL = "https://youtu.be/0IPbKyLVDh4" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 103, CourseId = 6, LectureName = "Lecture16", URL = "https://youtu.be/yf0LLFg2rqk" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 104, CourseId = 6, LectureName = "Lecture17", URL = "https://youtu.be/3la8rtPF5gU" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 105, CourseId = 6, LectureName = "Lecture18", URL = "https://youtu.be/2ZDK6v2FZlI" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 106, CourseId = 6, LectureName = "Lecture19", URL = "https://youtu.be/PTlCq7GEpCo" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 107, CourseId = 6, LectureName = "Lecture20", URL = "https://youtu.be/FcOa2G9kJPE" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 108, CourseId = 6, LectureName = "Lecture21", URL = "https://youtu.be/ojx-0zVeIr4" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 109, CourseId = 6, LectureName = "Lecture22", URL = "https://youtu.be/ZFXCM2ttZh4" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 110, CourseId = 6, LectureName = "Lecture23", URL = "https://youtu.be/YVdA86aSBGY" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 111, CourseId = 6, LectureName = "Lecture24", URL = "https://youtu.be/0JZ6EW-QrJw" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 112, CourseId = 6, LectureName = "Lecture25", URL = "https://youtu.be/safz1yCVYxo" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 113, CourseId = 6, LectureName = "Lecture26", URL = "https://youtu.be/RBWe_ZlSzjQ" });

            //////    // Course 7

            modelBuilder.Entity<Course>().HasData(new Course { CourseId = 7, CourseName = "SQL Server", Description = "This course is an introduction to the SQL Server database management system. SQL Server is a powerful database platform that is used by businesses of all sizes. In this course, you will learn the basics of SQL Server, including creating databases, tables, and views. You will also learn how to write SQL queries to retrieve and manipulate data." });

            //////    //Lectures

            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 114, CourseId = 7, LectureName = "Lecture1", URL = "https://youtu.be/8vTCyhDyRjg" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 115, CourseId = 7, LectureName = "Lecture2", URL = "https://youtu.be/TuZ0lkMLQQA" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 116, CourseId = 7, LectureName = "Lecture3", URL = "https://youtu.be/kLIOUXxvJ9E" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 117, CourseId = 7, LectureName = "Lecture4", URL = "https://youtu.be/_S6CITm-h6w" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 118, CourseId = 7, LectureName = "Lecture5", URL = "https://youtu.be/Yp1MKeIG-M4" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 119, CourseId = 7, LectureName = "Lecture6", URL = "https://youtu.be/Yp1MKeIG-M4" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 120, CourseId = 7, LectureName = "Lecture7", URL = "https://youtu.be/IneUOPTjSRc" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 121, CourseId = 7, LectureName = "Lecture8", URL = "https://youtu.be/84KXr0zi56g" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 122, CourseId = 7, LectureName = "Lecture9", URL = "https://youtu.be/84KXr0zi56g" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 123, CourseId = 7, LectureName = "Lecture10", URL = "https://youtu.be/t9KheZYSBYc" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 124, CourseId = 7, LectureName = "Lecture11", URL = "https://youtu.be/2SYyb6gNpfg" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 125, CourseId = 7, LectureName = "Lecture12", URL = "https://youtu.be/xGuAAp4J3UE" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 126, CourseId = 7, LectureName = "Lecture13", URL = "https://youtu.be/Ma9DW01DheA" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 127, CourseId = 7, LectureName = "Lecture15", URL = "https://youtu.be/cYqBBAYNdk8" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 128, CourseId = 7, LectureName = "Lecture16", URL = "https://youtu.be/yGbF79TedtI" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 129, CourseId = 7, LectureName = "Lecture14", URL = "https://youtu.be/IMK9hHEB0Cs" });

            ////// Course 8  
            modelBuilder.Entity<Course>().HasData(new Course { CourseId = 8, CourseName = "JavaScript", Description = "This course is an introduction to the JavaScript programming language. JavaScript is a powerful language that can be used to create interactive web pages, games, and mobile apps. In this course, you will learn the basics of JavaScript, including variables, functions, objects, and control flow. You will also learn how to use JavaScript to interact with the DOM, create animations, and build web applications." });

            ////Lectures
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 130, CourseId = 8, LectureName = "Lecture1", URL = "https://youtu.be/zBPeGR48_vE" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 131, CourseId = 8, LectureName = "Lecture2", URL = "https://youtu.be/sEGC-adSKXo" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 132, CourseId = 8, LectureName = "Lecture3", URL = "https://youtu.be/sEGC-adSKXo" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 133, CourseId = 8, LectureName = "Lecture4", URL = "https://youtu.be/plOo5hNVQJU" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 134, CourseId = 8, LectureName = "Lecture5", URL = "https://youtu.be/yjE_xXL26qA" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 135, CourseId = 8, LectureName = "Lecture6", URL = "https://youtu.be/jfQyMPzPTjY" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 136, CourseId = 8, LectureName = "Lecture7", URL = "https://youtu.be/nMQlXMHMz_Y" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 137, CourseId = 8, LectureName = "Lecture8", URL = "https://youtu.be/S2JVtEwa-kU" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 138, CourseId = 8, LectureName = "Lecture9", URL = "https://youtu.be/yPJCFWLd23o" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 139, CourseId = 8, LectureName = "Lecture10", URL = "https://youtu.be/yPJCFWLd23o" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 140, CourseId = 8, LectureName = "Lecture11", URL = "https://youtu.be/Fk3tdDAWkCI" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 141, CourseId = 8, LectureName = "Lecture12", URL = "https://youtu.be/sQ7YA0x8eUg" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 142, CourseId = 8, LectureName = "Lecture13", URL = "https://youtu.be/wCijt0OjnHc" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 143, CourseId = 8, LectureName = "Lecture14", URL = "https://youtu.be/onTQRpF15hI" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 144, CourseId = 8, LectureName = "Lecture15", URL = "https://youtu.be/CNGv0soYFn0" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 145, CourseId = 8, LectureName = "Lecture16", URL = "https://youtu.be/CNohrcgM_hU" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 146, CourseId = 8, LectureName = "Lecture17", URL = "https://youtu.be/3Uy5cJ-UpS0" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 147, CourseId = 8, LectureName = "Lecture18", URL = "https://youtu.be/RNrrcxr-_PU" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 148, CourseId = 8, LectureName = "Lecture19", URL = "https://youtu.be/G0PC7D3XZBA" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 149, CourseId = 8, LectureName = "Lecture20", URL = "https://youtu.be/DeFK4lS5LIA" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 150, CourseId = 8, LectureName = "Lecture21", URL = "https://youtu.be/jfC2tX-NUaI" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 151, CourseId = 8, LectureName = "Lecture22", URL = "https://youtu.be/n5mvncHb-Y0" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 152, CourseId = 8, LectureName = "Lecture23", URL = "https://youtu.be/MBLCbJvyaA0" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 153, CourseId = 8, LectureName = "Lecture24", URL = "https://youtu.be/1HEG5bvjJIA" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 154, CourseId = 8, LectureName = "Lecture25", URL = "https://youtu.be/1HEG5bvjJIA" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 155, CourseId = 8, LectureName = "Lecture26", URL = "https://youtu.be/hjWt3PQktJ8" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 156, CourseId = 8, LectureName = "Lecture27", URL = "https://youtu.be/LWeRIGGRZVk" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 157, CourseId = 8, LectureName = "Lecture28", URL = "https://youtu.be/tM4aKXtaOrE" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 158, CourseId = 8, LectureName = "Lecture29", URL = "https://youtu.be/_AQ9RBQcNMA" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 159, CourseId = 8, LectureName = "Lecture30", URL = "https://youtu.be/eOCfFxLGS-o" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 160, CourseId = 8, LectureName = "Lecture31", URL = "https://youtu.be/hZF_0dZnpvo" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 161, CourseId = 8, LectureName = "Lecture32", URL = "https://youtu.be/Sm4AZFIc39Y" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 162, CourseId = 8, LectureName = "Lecture33", URL = "https://youtu.be/EQJ4w3ypF9o" });

            //Course 9  HR

            modelBuilder.Entity<Course>().HasData(new Course { CourseId = 9, CourseName = "HR", Description = "Explore the essentials of Human Resources Management in this introductory course. Understand the core functions of HR, including recruitment, training, employee relations, and more. Learn about legal and ethical considerations, workplace diversity, and the role of HR in fostering a positive organizational culture. Discover the basics of compensation, communication, and emerging HR trends. No prior HR knowledge required." });

            //Lectures
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 164, CourseId = 9, LectureName = "Lecture1", URL = "https://www.youtube.com/watch?v=c8_avX9miag&list=PLN55WL2iKzD6E3rW7HtI-VZzLZFzbJP3f" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 165, CourseId = 9, LectureName = "Lecture2", URL = "https://www.youtube.com/watch?v=rVyJXnZEp2A&list=PLN55WL2iKzD6E3rW7HtI-VZzLZFzbJP3f&index=2" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 166, CourseId = 9, LectureName = "Lecture3", URL = "https://www.youtube.com/watch?v=awuJ2O2SLUs&list=PLN55WL2iKzD6E3rW7HtI-VZzLZFzbJP3f&index=3" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 167, CourseId = 9, LectureName = "Lecture4", URL = "https://www.youtube.com/watch?v=to0b5yZtchc&list=PLN55WL2iKzD6E3rW7HtI-VZzLZFzbJP3f&index=4" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 168, CourseId = 9, LectureName = "Lecture5", URL = "https://www.youtube.com/watch?v=FwJ3n6KvK1A&list=PLN55WL2iKzD6E3rW7HtI-VZzLZFzbJP3f&index=5" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 169, CourseId = 9, LectureName = "Lecture6", URL = "https://www.youtube.com/watch?v=iY6e_NDCJgM&list=PLN55WL2iKzD6E3rW7HtI-VZzLZFzbJP3f&index=6" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 170, CourseId = 9, LectureName = "Lecture7", URL = "https://www.youtube.com/watch?v=VZ-MSZXnUiw&list=PLN55WL2iKzD6E3rW7HtI-VZzLZFzbJP3f&index=7" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 171, CourseId = 9, LectureName = "Lecture8", URL = "https://www.youtube.com/watch?v=Pk8hN7lw_RA&list=PLN55WL2iKzD6E3rW7HtI-VZzLZFzbJP3f&index=8" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 172, CourseId = 9, LectureName = "Lecture9", URL = "https://www.youtube.com/watch?v=9zQTC8bBEhs&list=PLN55WL2iKzD6E3rW7HtI-VZzLZFzbJP3f&index=9" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 173, CourseId = 9, LectureName = "Lecture10", URL = "https://www.youtube.com/watch?v=9zQTC8bBEhs&list=PLN55WL2iKzD6E3rW7HtI-VZzLZFzbJP3f&index=10" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 174, CourseId = 9, LectureName = "Lecture11", URL = "https://www.youtube.com/watch?v=9zQTC8bBEhs&list=PLN55WL2iKzD6E3rW7HtI-VZzLZFzbJP3f&index=11" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 175, CourseId = 9, LectureName = "Lecture12", URL = "https://www.youtube.com/watch?v=9zQTC8bBEhs&list=PLN55WL2iKzD6E3rW7HtI-VZzLZFzbJP3f&index=12" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 176, CourseId = 9, LectureName = "Lecture13", URL = "https://www.youtube.com/watch?v=9zQTC8bBEhs&list=PLN55WL2iKzD6E3rW7HtI-VZzLZFzbJP3f&index=13" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 177, CourseId = 9, LectureName = "Lecture14", URL = "https://www.youtube.com/watch?v=9zQTC8bBEhs&list=PLN55WL2iKzD6E3rW7HtI-VZzLZFzbJP3f&index=14" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 178, CourseId = 9, LectureName = "Lecture15", URL = "https://www.youtube.com/watch?v=9zQTC8bBEhs&list=PLN55WL2iKzD6E3rW7HtI-VZzLZFzbJP3f&index=15" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 179, CourseId = 9, LectureName = "Lecture16", URL = "https://www.youtube.com/watch?v=9zQTC8bBEhs&list=PLN55WL2iKzD6E3rW7HtI-VZzLZFzbJP3f&index=16" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 180, CourseId = 9, LectureName = "Lecture16", URL = "https://www.youtube.com/watch?v=9zQTC8bBEhs&list=PLN55WL2iKzD6E3rW7HtI-VZzLZFzbJP3f&index=16" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 181, CourseId = 9, LectureName = "Lecture17", URL = "https://www.youtube.com/watch?v=9zQTC8bBEhs&list=PLN55WL2iKzD6E3rW7HtI-VZzLZFzbJP3f&index=17" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 182, CourseId = 9, LectureName = "Lecture18", URL = "https://www.youtube.com/watch?v=9zQTC8bBEhs&list=PLN55WL2iKzD6E3rW7HtI-VZzLZFzbJP3f&index=18" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 183, CourseId = 9, LectureName = "Lecture19", URL = "https://www.youtube.com/watch?v=9zQTC8bBEhs&list=PLN55WL2iKzD6E3rW7HtI-VZzLZFzbJP3f&index=19" });

            //Course 10 HYBRID
            modelBuilder.Entity<Course>().HasData(new Course { CourseId = 10, CourseName = "Hybrid", Description = "Explore the essentials of Human Resources Management in this introductory course. Understand the core functions of HR, including recruitment, training, employee relations, and more. Learn about legal and ethical considerations, workplace diversity, and the role of HR in fostering a positive organizational culture. Discover the basics of compensation, communication, and emerging HR trends. No prior HR knowledge required." });

            //Lecture

            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 184, CourseId = 9, LectureName = "Lecture1", URL = "https://www.youtube.com/watch?v=QTcFvi3LswE&list=PL9-f9hWLZS62VF18qPQ1gC7NqIAjaClsl" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 185, CourseId = 9, LectureName = "Lecture2", URL = "https://youtu.be/V76lKFm_gYI" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 186, CourseId = 9, LectureName = "Lecture3", URL = "https://youtu.be/cE0T-XPEcyI" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 187, CourseId = 9, LectureName = "Lecture4", URL = "https://youtu.be/RCbZjPHC1gg" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 188, CourseId = 9, LectureName = "Lecture5", URL = "https://youtu.be/k9kdw77vbek" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 189, CourseId = 9, LectureName = "Lecture6", URL = "https://youtu.be/4ceMVqbiKqA" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 190, CourseId = 9, LectureName = "Lecture7", URL = "https://youtu.be/dx5iOfkvZcA" });

            //Course 11 OIL & GAS
            modelBuilder.Entity<Course>().HasData(new Course { CourseId = 11, CourseName = "Oil, & Gas", Description = "This course provides an overview of the oil and gas industry, from the exploration and extraction of oil and gas to the refining and transportation of these commodities. Topics covered include the geology of oil and gas deposits, the principles of drilling and completion, the economics of the oil and gas industry, and the environmental impact of oil and gas production." });

            //Lectures
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 191, CourseId = 11, LectureName = "Lecture1", URL = "https://youtu.be/RabOe1KTlm8" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 192, CourseId = 11, LectureName = "Lecture2", URL = "https://youtu.be/RabOe1KTlm8" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 193, CourseId = 11, LectureName = "Lecture3", URL = "https://youtu.be/u6Xcu5-WXKc" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 194, CourseId = 11, LectureName = "Lecture4", URL = "https://youtu.be/Bpd2r6ZxFOc" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 195, CourseId = 11, LectureName = "Lecture5", URL = "https://youtu.be/TXoIoUfBN34" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 196, CourseId = 11, LectureName = "Lecture6", URL = "https://youtu.be/msefXfRSGOE" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 197, CourseId = 11, LectureName = "Lecture7", URL = "https://youtu.be/Blu8gTqmbEA" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 198, CourseId = 11, LectureName = "Lecture8", URL = "https://youtu.be/AUvetlVvT5I" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 199, CourseId = 11, LectureName = "Lecture9", URL = "https://youtu.be/MdGd6jun-j8" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 200, CourseId = 11, LectureName = "Lecture10", URL = "https://youtu.be/pwnORiU-_Hg" });

            // Course 12 FINANCE
            modelBuilder.Entity<Course>().HasData(new Course { CourseId = 12, CourseName = "Finance", Description = "This course provides an introduction to the field of finance, covering the basic concepts and tools used in financial analysis and decision-making. Topics include the time value of money, financial statements, risk and return, capital budgeting, and portfolio management." });
            //Lecture
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 201, CourseId = 12, LectureName = "Lecture1", URL = "https://youtu.be/TKoLoLVI_Js" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 202, CourseId = 12, LectureName = "Lecture2", URL = "https://youtu.be/TKoLoLVI_Js" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 203, CourseId = 12, LectureName = "Lecture3", URL = "https://youtu.be/y_T3kubRm7Q" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 204, CourseId = 12, LectureName = "Lecture4", URL = "https://youtu.be/TKoLoLVI_Js" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 205, CourseId = 12, LectureName = "Lecture5", URL = "https://youtu.be/BbdbjW8Pq04" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 206, CourseId = 12, LectureName = "Lecture6", URL = "https://youtu.be/PMENh4UWr-Y" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 207, CourseId = 12, LectureName = "Lecture7", URL = "https://youtu.be/rBWBUKZd4WY" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 208, CourseId = 12, LectureName = "Lecture8", URL = " https://youtu.be/82V2CafoYs0" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 209, CourseId = 12, LectureName = "Lecture9", URL = "https://youtu.be/GbpHHt08obE" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 210, CourseId = 12, LectureName = "Lecture10", URL = "https://youtu.be/4UKaQpe1Yfs" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 211, CourseId = 12, LectureName = "Lecture11", URL = "https://youtu.be/0IlSi0pyQD4" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 212, CourseId = 12, LectureName = "Lecture12", URL = "https://youtu.be/FXbXksS4kNs" });

            //Course 13
            modelBuilder.Entity<Course>().HasData(new Course { CourseId = 13, CourseName = "GCS", Description = "In today's competitive business landscape, exceptional customer support is a cornerstone of success. Elevate your customer service skills to new heights with our comprehensive course on Excellence in Customer Support. Designed for professionals across industries, this course offers a deep dive into proven strategies, techniques, and best practices to provide outstanding customer experiences and build lasting relationships." });
            //Lectures
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 213, CourseId = 13, LectureName = "Lecture1", URL = "https://youtu.be/MSend7ZUtfQ" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 214, CourseId = 13, LectureName = "Lecture2", URL = "https://youtu.be/u41V1QamyqE" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 215, CourseId = 13, LectureName = "Lecture3", URL = "https://youtu.be/-SeeEIvOYxc" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 216, CourseId = 13, LectureName = "Lecture4", URL = "https://youtu.be/5GbLoNHKNGE" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 217, CourseId = 13, LectureName = "Lecture5", URL = "https://youtu.be/sgFViiFPMDA" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 218, CourseId = 13, LectureName = "Lecture6", URL = "https://youtu.be/sgFViiFPMDA" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 219, CourseId = 13, LectureName = "Lecture7", URL = "https://youtu.be/P2xV38Qy7ug" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 220, CourseId = 13, LectureName = "Lecture8", URL = "https://youtu.be/4Y5BBN6Pwv0" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 221, CourseId = 13, LectureName = "Lecture9", URL = "https://youtu.be/crc9ZrKf5lA" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 222, CourseId = 13, LectureName = "Lecture10", URL = "https://youtu.be/sgFViiFPMDA" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 223, CourseId = 13, LectureName = "Lecture11", URL = "https://youtu.be/WkNiJmqJbEM" });
            modelBuilder.Entity<Lecture>().HasData(new Lecture { LectureId = 224, CourseId = 13, LectureName = "Lecture12", URL = "https://youtu.be/fdtD0dz28zY" });

            // Log
            modelBuilder.Entity<log>().HasData(new log { Id = 3, action = "fired", actor = "Homos Awadallah", time_of_occurance = new DateTime(2019, 9, 7, 8, 0, 0) });
            modelBuilder.Entity<log>().HasData(new log { Id = 2, action = "fired", actor = "Ahmad Mohamed", time_of_occurance = new DateTime(2019, 9, 7, 8, 0, 0) });
            modelBuilder.Entity<log>().HasData(new log { Id = 1, action = "fired", actor = "Mostafa Hosny", time_of_occurance = new DateTime(2019, 9, 7, 8, 0, 0) });

            // User Course
            modelBuilder.Entity<User_course>().HasData(new User_course { UserId = 14, CourseId = 1 });
            modelBuilder.Entity<User_course>().HasData(new User_course { UserId = 15, CourseId = 2 });
            modelBuilder.Entity<User_course>().HasData(new User_course { UserId = 16, CourseId = 3 });
            modelBuilder.Entity<User_course>().HasData(new User_course { UserId = 17, CourseId = 4 });
            modelBuilder.Entity<User_course>().HasData(new User_course { UserId = 15, CourseId = 5 });
            modelBuilder.Entity<User_course>().HasData(new User_course { UserId = 18, CourseId = 6 });
            modelBuilder.Entity<User_course>().HasData(new User_course { UserId = 17, CourseId = 7 });
            modelBuilder.Entity<User_course>().HasData(new User_course { UserId = 18, CourseId = 8 });
            modelBuilder.Entity<User_course>().HasData(new User_course { UserId = 27, CourseId = 9 });
            modelBuilder.Entity<User_course>().HasData(new User_course { UserId = 28, CourseId = 10 });
            modelBuilder.Entity<User_course>().HasData(new User_course { UserId = 29, CourseId = 11 });



            modelBuilder.Entity<Feedback>().HasData(new Feedback { FeedbackId = 1, FeedbackComment = "HAMADA SA7 EL SA7", UserId = 1, FeedbackDate = new DateTime(2019, 9, 7, 8, 0, 0), FeedbackValue = 10 });
            modelBuilder.Entity<Feedback>().HasData(new Feedback { FeedbackId = 2, FeedbackComment = "HAMADA SA7 EL SA7 2 ", UserId = 2, FeedbackDate = new DateTime(2023, 9, 7, 8, 0, 0), FeedbackValue = 9 });

            // ccna quiz questions
            modelBuilder.Entity<Question>().HasData(new Question { QuestionId = 1, QuestionText = "What is the purpose of a VLAN?", correct_choice = "To create separate broadcast domains on a network", Wrong_choice1 = "To create separate security zones on a network", Wrong_choice2 = "To create separate routing domains on a network", Wrong_choice3 = "None of the above", CourseId = 3 });
            modelBuilder.Entity<Question>().HasData(new Question { QuestionId = 2, QuestionText = "Which of the following is a type of network topology?", correct_choice = "All of the above", Wrong_choice1 = "Star", Wrong_choice2 = "Ring", Wrong_choice3 = "Mesh", CourseId = 3 });
            modelBuilder.Entity<Question>().HasData(new Question { QuestionId = 3, QuestionText = "Which of the following is the default subnet mask for a Class C IP address?", correct_choice = "255.255.255.0", Wrong_choice1 = ". 255.255.0.0", Wrong_choice2 = "255.0.0.0", Wrong_choice3 = "192.168.0.0", CourseId = 3 });
            modelBuilder.Entity<Question>().HasData(new Question { QuestionId = 4, QuestionText = "Which routing protocol uses cost as its metric?", correct_choice = "EIGRP", Wrong_choice1 = "OSPF", Wrong_choice2 = "RIP", Wrong_choice3 = "BGP", CourseId = 3 });
            modelBuilder.Entity<Question>().HasData(new Question { QuestionId = 5, QuestionText = "Which of the following is a type of network traffic?", correct_choice = "All of the above", Wrong_choice1 = "VOIP", Wrong_choice2 = "HTTP", Wrong_choice3 = "FTP", CourseId = 3 });
            modelBuilder.Entity<Question>().HasData(new Question { QuestionId = 6, QuestionText = "Which of the following is the OSI model layer responsible for providing reliable communication between two hosts?", correct_choice = "Transport layer", Wrong_choice1 = "Physical layer", Wrong_choice2 = "Data link layer", Wrong_choice3 = "Network layer", CourseId = 3 });
            modelBuilder.Entity<Question>().HasData(new Question { QuestionId = 7, QuestionText = "Which command is used to view the MAC address table on a Cisco switch?", correct_choice = "Show MAC address-table", Wrong_choice1 = "Show IP route", Wrong_choice2 = "Show interfaces", Wrong_choice3 = "Show running-config", CourseId = 3 });
            modelBuilder.Entity<Question>().HasData(new Question { QuestionId = 8, QuestionText = "Which of the following is a private IP address range?", correct_choice = "All of the above", Wrong_choice1 = "10.0.0.0/8", Wrong_choice2 = "172.16.0.0/12", Wrong_choice3 = "192.168.0.0/16", CourseId = 3 });
            modelBuilder.Entity<Question>().HasData(new Question { QuestionId = 9, QuestionText = "Which of the following is a Layer 2 switch?", correct_choice = "Cisco 2960", Wrong_choice1 = "Cisco 3750", Wrong_choice2 = "Cisco 4500", Wrong_choice3 = "Cisco 7600", CourseId = 3 });
            modelBuilder.Entity<Question>().HasData(new Question { QuestionId = 10, QuestionText = "What is the default administrative distance for OSPF?", correct_choice = "1", Wrong_choice1 = "10", Wrong_choice2 = "100", Wrong_choice3 = "110", CourseId = 3 });
            modelBuilder.Entity<Question>().HasData(new Question { QuestionId = 11, QuestionText = "Which of the following is a routing protocol that is based on distance vector?", correct_choice = "RIP", Wrong_choice1 = "OSPF", Wrong_choice2 = "EIGRP", Wrong_choice3 = "BGP", CourseId = 3 });
            modelBuilder.Entity<Question>().HasData(new Question { QuestionId = 12, QuestionText = "Which command is used to configure a static route on a Cisco router?", correct_choice = "IP route", Wrong_choice1 = "Route add", Wrong_choice2 = "IP static", Wrong_choice3 = "Route", CourseId = 3 });
            modelBuilder.Entity<Question>().HasData(new Question { QuestionId = 13, QuestionText = "Which of the following is a type of network security appliance?", correct_choice = "Firewall", Wrong_choice1 = "Switch", Wrong_choice2 = "Router", Wrong_choice3 = "Hub", CourseId = 3 });
            modelBuilder.Entity<Question>().HasData(new Question { QuestionId = 14, QuestionText = "What is the purpose of a DHCP server?", correct_choice = "To assign IP addresses to hosts on a network", Wrong_choice1 = "To route traffic between different networks", Wrong_choice2 = "To provide name resolution services", Wrong_choice3 = "To provide security for a network", CourseId = 3 });
            modelBuilder.Entity<Question>().HasData(new Question { QuestionId = 15, QuestionText = "What is the purpose of a spanning tree protocol?", correct_choice = "To prevent loops in a network", Wrong_choice1 = "To provide load balancing for a network", Wrong_choice2 = "To provide security for a network", Wrong_choice3 = "To provide fault tolerance for a network", CourseId = 3 });


            // Resources
            modelBuilder.Entity<Resources>().HasData(new Resources { ResourceID = 1, ContactInfo = "18773425173", CompanyPolicy = "Schneider Electric has a number of company policies that are designed to ensure that the company operates in an ethical and responsible manner. These policies cover a wide range of topics, including:\r\n\r\nAnti-corruption\r\nAnti-harassment and anti-discrimination\r\nGifts and hospitality\r\nDiversity and inclusion\r\nEnergy\r\nEnvironment\r\nHuman rights\r\nQuality\r\nHealth and safety\r\nWhistleblowing", UsefulLink = "https://www.se.com/us/en/all-products , https://www.se.com/us/en/work/solutions/ , https://www.se.com/us/en/work/services/ , https://blog.se.com/ , https://www.se.com/us/en/work/services/register-your-product/ , https://schneiderele.taleo.net/careersection/2/jobsearch.ftl?lang=en&keyword=&CATEGORY=-1&LOCATION=-1 , https://download.schneider-electric.com/files?p_Doc_Ref=NAM-Promo-terms-and-conditions" });


            //FAQS
            modelBuilder.Entity<FAQ>().HasData(new FAQ { QuestionId = 1, Question = "What is Schneider Electric?", Answer = "Schneider Electric is a French multinational company that specializes in digital automation and energy management. It is the world's largest supplier of electrical distribution equipment and one of the world's leading suppliers of industrial automation and control systems." });
            modelBuilder.Entity<FAQ>().HasData(new FAQ { QuestionId = 2, Question = "What are Schneider Electric's products and services?", Answer = "Schneider Electric's products and services include:\r\n\r\n* Electrical distribution equipment, such as circuit breakers, switches, and fuses\r\n* Industrial automation and control systems, such as programmable logic controllers (PLCs) and human-machine interfaces (HMIs)\r\n* Building automation systems, such as lighting controls and HVAC systems\r\n* Power quality solutions, such as surge protectors and filters\r\n* Energy management software" });
            modelBuilder.Entity<FAQ>().HasData(new FAQ { QuestionId = 3, Question = "How can I contact Schneider Electric?", Answer = "You can contact Schneider Electric by phone, email, or through their website. The contact information for each region can be found on their website." });
            modelBuilder.Entity<FAQ>().HasData(new FAQ { QuestionId = 4, Question = "What are some of the benefits of using Schneider Electric products and services?\r\n", Answer = "* Reliability and durability\r\n* Energy efficiency\r\n* Safety\r\n* Scalability\r\n* Flexibility\r\n* Interoperability" });
            modelBuilder.Entity<FAQ>().HasData(new FAQ { QuestionId = 5, Question = "What is the future of Schneider Electric?", Answer = "Schneider Electric is committed to the future of energy and automation. They are investing in research and development to develop new products and services that will help their customers save energy, improve safety, and increase productivity." });
            modelBuilder.Entity<FAQ>().HasData(new FAQ { QuestionId = 6, Question = "How do I apply for a job at Schneider Electric?", Answer = "You can apply for a job at Schneider Electric by visiting their website and submitting your resume and cover letter." });
            modelBuilder.Entity<FAQ>().HasData(new FAQ { QuestionId = 7, Question = "What are the benefits of working at Schneider Electric?", Answer = "* Competitive salary and benefits\r\n * 401(k) plan with company match\r\n* Paid vacation and sick time\r\n* Health insurance\r\n* Life insurance\r\n* Disability insurance\r\n* Tuition reimbursement\r\n* Employee discounts\r\n* Wellness programs" });
            modelBuilder.Entity<FAQ>().HasData(new FAQ { QuestionId = 8, Question = "What is the work-life balance like at Schneider Electric?", Answer = "Schneider Electric is committed to providing its employees with a good work-life balance. They offer flexible work arrangements and encourage employees to take advantage of their vacation and sick time." });
            modelBuilder.Entity<FAQ>().HasData(new FAQ { QuestionId = 9, Question = "What is the culture like at Schneider Electric?", Answer = "Schneider Electric is a global company with a diverse workforce. The culture is collaborative and supportive, and employees are encouraged to take risks and innovate." });
            modelBuilder.Entity<FAQ>().HasData(new FAQ { QuestionId = 10, Question = "What are the opportunities for growth at Schneider Electric?", Answer = "Schneider Electric is a growing company with a lot of opportunities for growth. There are opportunities for employees to move into new roles, take on more responsibility, and learn new skills." });
            modelBuilder.Entity<FAQ>().HasData(new FAQ { QuestionId = 11, Question = "How can I get promoted at Schneider Electric?", Answer = "There are a few things you can do to get promoted at Schneider Electric:\r\n\r\n* Perform your job well and meet or exceed expectations.\r\n* Take on new challenges and responsibilities.\r\n* Be a team player and be willing to help others.\r\n* Be proactive and take initiative.\r\n* Be visible and make your contributions known." });
            modelBuilder.Entity<FAQ>().HasData(new FAQ { QuestionId = 12, Question = "Where can I find more information about Schneider Electric?", Answer = "You can find more information about Schneider Electric on their website: https://www.schneider-electric.com/" });


        }
    }
}
