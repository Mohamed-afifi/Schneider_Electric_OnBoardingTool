﻿using OnboardingTool.Models.Domain;

namespace OnboardingTool.Interfaces
{
    public interface I_Report
    {
        public string reportProblem(int eid, string pDescription);
        public string Report(int eid, int cid);
        public List<Report> showReportproblem();
    }
}
