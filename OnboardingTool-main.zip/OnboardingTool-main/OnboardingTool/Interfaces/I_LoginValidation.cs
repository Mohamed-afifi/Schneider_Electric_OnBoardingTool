using OnboardingTool.Models.Domain;

namespace BoardingSystem.Interfaces
{
    public interface I_LoginValidation
    {
        public User Login_Validation(string email, string password);
    }
}
