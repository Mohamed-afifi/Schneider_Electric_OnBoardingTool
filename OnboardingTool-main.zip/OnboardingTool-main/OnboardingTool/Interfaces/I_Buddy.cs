using Microsoft.EntityFrameworkCore.SqlServer.Query.Internal;
using OnboardingTool.Models.Domain;

namespace BoardingSystem.Interfaces
{
    public interface I_Buddy
    {
        public List<User> viewBuddy();
        public string assignBuddy(int eId, int bId);
        public string updateBuddy(int id);
        public string CheckBuddies(int bid);
        public List<User> viewNewEmployeeOfBuddy(int id);

    }
}
