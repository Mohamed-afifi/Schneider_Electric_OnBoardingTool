﻿using OnboardingTool.Models.Domain;

namespace OnboardingTool.Interfaces
{
    public interface I_Feedback
    {
        public string addFeedback(string comment, int value,int ID);

        public List<Feedback> showFeedback();
    }
}
