using System.Collections.Generic;
using OnboardingTool.Models.Domain;
using OnboardingTool.Services;

namespace BoardingSystem.Interfaces
{
    public interface I_Course
    {
        public string assignCourse(User_course course);
        public Course takeCourse(Course course);
        public string deleteCourse(int id);
        public Course addCourse(Course course);
        public string updateCourse(Course course);
        public void removeAssigned(int Course_id);
        public void removeLectures(int Course_id);
        public List<Course> showCourses();
        public List<Course> seeUserCourses(int eid);
        public Course showCourse(int CourseId);
        //public List<Lecture> showLectures(int CourseId);
        public KeyValuePair<Course, List<Lecture>> showLectures(int CourseId);
    }
}
