﻿namespace OnboardingTool.Interfaces
{
    public interface I_Departments
    {
        
    }
}
