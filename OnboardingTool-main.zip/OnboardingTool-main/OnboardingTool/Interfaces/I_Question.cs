﻿using OnboardingTool.Models.Domain;
using OnboardingTool.Services;

namespace BoardingSystem.Interfaces
{
    public interface I_Question
    {
        List<Question> GetRandomQuestions(int id);

    }

}