﻿using OnboardingTool.Models.Domain;

namespace OnboardingTool.Interfaces
{
    public interface I_FAQ
    {
        public string addFAQ(string Question, string Answer);
        public List<FAQ> seeFAQ();
    }
}
