﻿using Microsoft.EntityFrameworkCore;
using OnboardingTool.Models.Domain;

namespace OnboardingTool.Interfaces
{
    public interface I_Resources
    {
        public List<Resources> viewContactInfo();
        public string addResource(string contactInfo, string companyPolicy,string usefulLink);
    }
}
