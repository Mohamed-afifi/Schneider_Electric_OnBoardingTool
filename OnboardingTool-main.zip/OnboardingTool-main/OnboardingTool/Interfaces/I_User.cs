using OnboardingTool.Models.Domain;
using OnboardingTool.Services;

namespace BoardingSystem.Interfaces
{
    public interface I_User
    {
        public string AddUser(User admin);
        public String removeUser(int id);
        public String updateUser(User user);
        public string PromoteManager(int id);
        public User downgradeManger(int id, string email);
        public User showBuddyRelation(int id);
        public User GetUser(int id);
        public List<List<string>> relationOfUsers();
        public List<User> GetManager();
        public List<User> GetEmployees();
        public List<User> GetNewEmployees();
        public List<User> GetFreeNewEmployees();
    }
}
