﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace OnboardingTool.Migrations
{
    /// <inheritdoc />
    public partial class added : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "User",
                keyColumn: "UserId",
                keyValue: 3,
                column: "is_buddy",
                value: true);

            migrationBuilder.UpdateData(
                table: "User",
                keyColumn: "UserId",
                keyValue: 4,
                column: "is_buddy",
                value: true);

            migrationBuilder.UpdateData(
                table: "User",
                keyColumn: "UserId",
                keyValue: 13,
                columns: new[] { "buddyId", "job_title" },
                values: new object[] { 3, "New Employee" });

            migrationBuilder.UpdateData(
                table: "User",
                keyColumn: "UserId",
                keyValue: 14,
                columns: new[] { "buddyId", "job_title", "new_employee" },
                values: new object[] { 4, "New Employee", true });

            migrationBuilder.UpdateData(
                table: "User",
                keyColumn: "UserId",
                keyValue: 15,
                columns: new[] { "buddyId", "job_title" },
                values: new object[] { 5, "New Employee" });

            migrationBuilder.UpdateData(
                table: "User",
                keyColumn: "UserId",
                keyValue: 16,
                columns: new[] { "buddyId", "job_title", "new_employee" },
                values: new object[] { 6, "New Employee", true });

            migrationBuilder.UpdateData(
                table: "User",
                keyColumn: "UserId",
                keyValue: 17,
                columns: new[] { "buddyId", "job_title" },
                values: new object[] { 23, "New Employee" });

            migrationBuilder.UpdateData(
                table: "User",
                keyColumn: "UserId",
                keyValue: 18,
                columns: new[] { "buddyId", "job_title", "new_employee" },
                values: new object[] { 32, "New Employee", true });

            migrationBuilder.UpdateData(
                table: "User",
                keyColumn: "UserId",
                keyValue: 23,
                column: "is_buddy",
                value: true);

            migrationBuilder.UpdateData(
                table: "User",
                keyColumn: "UserId",
                keyValue: 27,
                columns: new[] { "FirsttimeLogin", "buddyId", "new_employee" },
                values: new object[] { true, 38, true });

            migrationBuilder.UpdateData(
                table: "User",
                keyColumn: "UserId",
                keyValue: 28,
                column: "buddyId",
                value: 45);

            migrationBuilder.UpdateData(
                table: "User",
                keyColumn: "UserId",
                keyValue: 29,
                columns: new[] { "FirsttimeLogin", "RoleId", "buddyId", "new_employee" },
                values: new object[] { true, 4, 7, true });

            migrationBuilder.UpdateData(
                table: "User",
                keyColumn: "UserId",
                keyValue: 32,
                columns: new[] { "buddyId", "is_buddy" },
                values: new object[] { 0, true });

            migrationBuilder.UpdateData(
                table: "User",
                keyColumn: "UserId",
                keyValue: 38,
                column: "is_buddy",
                value: true);

            migrationBuilder.UpdateData(
                table: "User",
                keyColumn: "UserId",
                keyValue: 45,
                column: "is_buddy",
                value: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "User",
                keyColumn: "UserId",
                keyValue: 3,
                column: "is_buddy",
                value: false);

            migrationBuilder.UpdateData(
                table: "User",
                keyColumn: "UserId",
                keyValue: 4,
                column: "is_buddy",
                value: false);

            migrationBuilder.UpdateData(
                table: "User",
                keyColumn: "UserId",
                keyValue: 13,
                columns: new[] { "buddyId", "job_title" },
                values: new object[] { 6, "Employee" });

            migrationBuilder.UpdateData(
                table: "User",
                keyColumn: "UserId",
                keyValue: 14,
                columns: new[] { "buddyId", "job_title", "new_employee" },
                values: new object[] { 6, "Employee", false });

            migrationBuilder.UpdateData(
                table: "User",
                keyColumn: "UserId",
                keyValue: 15,
                columns: new[] { "buddyId", "job_title" },
                values: new object[] { 0, "Employee" });

            migrationBuilder.UpdateData(
                table: "User",
                keyColumn: "UserId",
                keyValue: 16,
                columns: new[] { "buddyId", "job_title", "new_employee" },
                values: new object[] { 0, "Employee", false });

            migrationBuilder.UpdateData(
                table: "User",
                keyColumn: "UserId",
                keyValue: 17,
                columns: new[] { "buddyId", "job_title" },
                values: new object[] { 0, "Employee" });

            migrationBuilder.UpdateData(
                table: "User",
                keyColumn: "UserId",
                keyValue: 18,
                columns: new[] { "buddyId", "job_title", "new_employee" },
                values: new object[] { 7, "Employee", false });

            migrationBuilder.UpdateData(
                table: "User",
                keyColumn: "UserId",
                keyValue: 23,
                column: "is_buddy",
                value: false);

            migrationBuilder.UpdateData(
                table: "User",
                keyColumn: "UserId",
                keyValue: 27,
                columns: new[] { "FirsttimeLogin", "buddyId", "new_employee" },
                values: new object[] { false, 26, false });

            migrationBuilder.UpdateData(
                table: "User",
                keyColumn: "UserId",
                keyValue: 28,
                column: "buddyId",
                value: 12);

            migrationBuilder.UpdateData(
                table: "User",
                keyColumn: "UserId",
                keyValue: 29,
                columns: new[] { "FirsttimeLogin", "RoleId", "buddyId", "new_employee" },
                values: new object[] { false, 2, 11, false });

            migrationBuilder.UpdateData(
                table: "User",
                keyColumn: "UserId",
                keyValue: 32,
                columns: new[] { "buddyId", "is_buddy" },
                values: new object[] { 26, false });

            migrationBuilder.UpdateData(
                table: "User",
                keyColumn: "UserId",
                keyValue: 38,
                column: "is_buddy",
                value: false);

            migrationBuilder.UpdateData(
                table: "User",
                keyColumn: "UserId",
                keyValue: 45,
                column: "is_buddy",
                value: false);
        }
    }
}
