﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace OnboardingTool.Migrations
{
    /// <inheritdoc />
    public partial class fixForMigration : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Course",
                columns: table => new
                {
                    CourseId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CourseName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Course", x => x.CourseId);
                });

            migrationBuilder.CreateTable(
                name: "Departments",
                columns: table => new
                {
                    DepartmentCode = table.Column<int>(type: "int", nullable: false),
                    DepartmentName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                });

            migrationBuilder.CreateTable(
                name: "FAQ",
                columns: table => new
                {
                    QuestionId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Question = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Answer = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FAQ", x => x.QuestionId);
                });

            migrationBuilder.CreateTable(
                name: "Feedback",
                columns: table => new
                {
                    FeedbackId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FeedbackValue = table.Column<int>(type: "int", nullable: false),
                    FeedbackComment = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UserId = table.Column<int>(type: "int", nullable: false),
                    FeedbackDate = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Feedback", x => x.FeedbackId);
                });

            migrationBuilder.CreateTable(
                name: "log",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    action = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    actor = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    time_of_occurance = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_log", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Reports",
                columns: table => new
                {
                    ReportId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserId = table.Column<int>(type: "int", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Reports", x => x.ReportId);
                });

            migrationBuilder.CreateTable(
                name: "Resources",
                columns: table => new
                {
                    ResourceID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ContactInfo = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CompanyPolicy = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    UsefulLink = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Resources", x => x.ResourceID);
                });

            migrationBuilder.CreateTable(
                name: "Role",
                columns: table => new
                {
                    RoleId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    title = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    new_employee = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Role", x => x.RoleId);
                });

            migrationBuilder.CreateTable(
                name: "User",
                columns: table => new
                {
                    UserId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    password = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    RoleId = table.Column<int>(type: "int", nullable: false),
                    age = table.Column<int>(type: "int", nullable: false),
                    phoneNum = table.Column<int>(type: "int", nullable: false),
                    job_title = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    is_buddy = table.Column<bool>(type: "bit", nullable: false),
                    buddyId = table.Column<int>(type: "int", nullable: false),
                    enrollment_date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    FirsttimeLogin = table.Column<bool>(type: "bit", nullable: false),
                    new_employee = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_User", x => x.UserId);
                });

            migrationBuilder.CreateTable(
                name: "lecture",
                columns: table => new
                {
                    LectureId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CourseId = table.Column<int>(type: "int", nullable: false),
                    LectureName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    URL = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_lecture", x => x.LectureId);
                    table.ForeignKey(
                        name: "FK_lecture_Course_CourseId",
                        column: x => x.CourseId,
                        principalTable: "Course",
                        principalColumn: "CourseId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Question",
                columns: table => new
                {
                    QuestionId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    QuestionText = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Wrong_choice1 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Wrong_choice2 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Wrong_choice3 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    correct_choice = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CourseId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Question", x => x.QuestionId);
                    table.ForeignKey(
                        name: "FK_Question_Course_CourseId",
                        column: x => x.CourseId,
                        principalTable: "Course",
                        principalColumn: "CourseId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "User_Course",
                columns: table => new
                {
                    CourseId = table.Column<int>(type: "int", nullable: false),
                    UserId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_User_Course", x => new { x.CourseId, x.UserId });
                    table.ForeignKey(
                        name: "FK_User_Course_Course_CourseId",
                        column: x => x.CourseId,
                        principalTable: "Course",
                        principalColumn: "CourseId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Userlog",
                columns: table => new
                {
                    logsId = table.Column<int>(type: "int", nullable: false),
                    usersUserId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Userlog", x => new { x.logsId, x.usersUserId });
                    table.ForeignKey(
                        name: "FK_Userlog_User_usersUserId",
                        column: x => x.usersUserId,
                        principalTable: "User",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Userlog_log_logsId",
                        column: x => x.logsId,
                        principalTable: "log",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Course",
                columns: new[] { "CourseId", "CourseName", "Description" },
                values: new object[,]
                {
                    { 1, "CS50", "CS50x course is an introduction to the intellectual enterprises of computer science and the art of programming for majors and non-majors alike, with or without prior programming experience. An entry-level course taught by David J. Malan, CS50x teaches students how to think algorithmically and solve problems efficiently. Topics include abstraction, algorithms, data structures, encapsulation, resource management, security, software engineering, and web development. Languages include C, Python, SQL, and JavaScript plus CSS and HTML. Problem sets inspired by real-world domains of biology, cryptography, finance, forensics, and gaming." },
                    { 2, "Angular", "This course is a comprehensive introduction to Angular, a popular open-source JavaScript framework for building single-page applications. It is designed for beginners with no prior experience with Angular or JavaScript.\r\n\r\nIn this course, you will learn the basics of Angular, including:\r\n\r\nThe Angular framework architecture\r\nComponents\r\nDirectives\r\nServices\r\nRouting\r\nForms\r\nHttp\r\nTesting\r\nYou will also learn how to build real-world Angular applications. By the end of this course, you will be able to:\r\n\r\nBuild single-page applications with Angular\r\nUse Angular components to create reusable user interface elements\r\nCreate custom directives to extend the functionality of Angular\r\nUse Angular services to access data and functionality from external sources\r\nImplement routing in your Angular applications\r\nCreate and validate forms in Angular\r\nMake HTTP requests in Angular\r\nTest your Angular applications" },
                    { 3, "CCNA", "Begin preparing for a networking career with this introduction to how networks operate. This course of the CCNA series introduces architectures, models, protocols, and networking elements – functions needed to support the operations and priorities of Fortune 500 companies to small innovative retailers. You’ll even get the chance to build simple local area networks (LANs). Developing a working knowledge of IP addressing schemes, foundational network security, you'll be able to perform basic configurations for routers and switches. No prerequisites required. After completing all three CCNA courses, you are ready to take the CCNA Certification. \r\nYou'll Learn to build simple LANs, perform basic configurations for routers and switches, and implement IPv4 and IPv6 addressing schemes.\r\nConfigure routers, switches, and end devices to provide access to local and remote network resources and to enable end-to-end connectivity between remote devices.\r\nDevelop critical thinking and problem-solving skills using real equipment and Cisco Packet Tracer.\r\nConfigure and troubleshoot connectivity a small network using security best practices." },
                    { 4, "HTML & CSS", "This course is a comprehensive introduction to the HTML and CSS markup languages. HTML is used to create the structure of a web page, while CSS is used to style the appearance of the HTML elements. In this course, you will learn the basics of both HTML and CSS, including tags, attributes, selectors, and properties. You will also learn how to use HTML and CSS to create a variety of web pages, including simple websites, landing pages, and blog posts." },
                    { 5, "Node JS", "This course is a comprehensive introduction to the Node.js programming language. Node.js is a popular platform for building scalable, real-time web applications. In this course, you will learn the basics of Node.js, including its event-driven architecture, its non-blocking I/O model, and its powerful ecosystem of modules. You will also learn how to build web applications with Node.js, including REST APIs, chat applications, and real-time multiplayer games." },
                    { 6, "TypeScript", "This course is an introduction to the TypeScript programming language. TypeScript is a superset of JavaScript that adds type safety to the language. This makes it easier to write robust and maintainable code. In this course, you will learn the basics of TypeScript, including variables, functions, objects, and classes. You will also learn how to use TypeScript to build web applications and Node.js servers." },
                    { 7, "SQL Server", "This course is an introduction to the SQL Server database management system. SQL Server is a powerful database platform that is used by businesses of all sizes. In this course, you will learn the basics of SQL Server, including creating databases, tables, and views. You will also learn how to write SQL queries to retrieve and manipulate data." },
                    { 8, "JavaScript", "This course is an introduction to the JavaScript programming language. JavaScript is a powerful language that can be used to create interactive web pages, games, and mobile apps. In this course, you will learn the basics of JavaScript, including variables, functions, objects, and control flow. You will also learn how to use JavaScript to interact with the DOM, create animations, and build web applications." },
                    { 9, "HR", "Explore the essentials of Human Resources Management in this introductory course. Understand the core functions of HR, including recruitment, training, employee relations, and more. Learn about legal and ethical considerations, workplace diversity, and the role of HR in fostering a positive organizational culture. Discover the basics of compensation, communication, and emerging HR trends. No prior HR knowledge required." },
                    { 10, "Hybrid", "Explore the essentials of Human Resources Management in this introductory course. Understand the core functions of HR, including recruitment, training, employee relations, and more. Learn about legal and ethical considerations, workplace diversity, and the role of HR in fostering a positive organizational culture. Discover the basics of compensation, communication, and emerging HR trends. No prior HR knowledge required." },
                    { 11, "Oil, & Gas", "This course provides an overview of the oil and gas industry, from the exploration and extraction of oil and gas to the refining and transportation of these commodities. Topics covered include the geology of oil and gas deposits, the principles of drilling and completion, the economics of the oil and gas industry, and the environmental impact of oil and gas production." },
                    { 12, "Finance", "This course provides an introduction to the field of finance, covering the basic concepts and tools used in financial analysis and decision-making. Topics include the time value of money, financial statements, risk and return, capital budgeting, and portfolio management." },
                    { 13, "GCS", "In today's competitive business landscape, exceptional customer support is a cornerstone of success. Elevate your customer service skills to new heights with our comprehensive course on Excellence in Customer Support. Designed for professionals across industries, this course offers a deep dive into proven strategies, techniques, and best practices to provide outstanding customer experiences and build lasting relationships." }
                });

            migrationBuilder.InsertData(
                table: "FAQ",
                columns: new[] { "QuestionId", "Answer", "Question" },
                values: new object[,]
                {
                    { 1, "Schneider Electric is a French multinational company that specializes in digital automation and energy management. It is the world's largest supplier of electrical distribution equipment and one of the world's leading suppliers of industrial automation and control systems.", "What is Schneider Electric?" },
                    { 2, "Schneider Electric's products and services include:\r\n\r\n* Electrical distribution equipment, such as circuit breakers, switches, and fuses\r\n* Industrial automation and control systems, such as programmable logic controllers (PLCs) and human-machine interfaces (HMIs)\r\n* Building automation systems, such as lighting controls and HVAC systems\r\n* Power quality solutions, such as surge protectors and filters\r\n* Energy management software", "What are Schneider Electric's products and services?" },
                    { 3, "You can contact Schneider Electric by phone, email, or through their website. The contact information for each region can be found on their website.", "How can I contact Schneider Electric?" },
                    { 4, "* Reliability and durability\r\n* Energy efficiency\r\n* Safety\r\n* Scalability\r\n* Flexibility\r\n* Interoperability", "What are some of the benefits of using Schneider Electric products and services?\r\n" },
                    { 5, "Schneider Electric is committed to the future of energy and automation. They are investing in research and development to develop new products and services that will help their customers save energy, improve safety, and increase productivity.", "What is the future of Schneider Electric?" },
                    { 6, "You can apply for a job at Schneider Electric by visiting their website and submitting your resume and cover letter.", "How do I apply for a job at Schneider Electric?" },
                    { 7, "* Competitive salary and benefits\r\n * 401(k) plan with company match\r\n* Paid vacation and sick time\r\n* Health insurance\r\n* Life insurance\r\n* Disability insurance\r\n* Tuition reimbursement\r\n* Employee discounts\r\n* Wellness programs", "What are the benefits of working at Schneider Electric?" },
                    { 8, "Schneider Electric is committed to providing its employees with a good work-life balance. They offer flexible work arrangements and encourage employees to take advantage of their vacation and sick time.", "What is the work-life balance like at Schneider Electric?" },
                    { 9, "Schneider Electric is a global company with a diverse workforce. The culture is collaborative and supportive, and employees are encouraged to take risks and innovate.", "What is the culture like at Schneider Electric?" },
                    { 10, "Schneider Electric is a growing company with a lot of opportunities for growth. There are opportunities for employees to move into new roles, take on more responsibility, and learn new skills.", "What are the opportunities for growth at Schneider Electric?" },
                    { 11, "There are a few things you can do to get promoted at Schneider Electric:\r\n\r\n* Perform your job well and meet or exceed expectations.\r\n* Take on new challenges and responsibilities.\r\n* Be a team player and be willing to help others.\r\n* Be proactive and take initiative.\r\n* Be visible and make your contributions known.", "How can I get promoted at Schneider Electric?" },
                    { 12, "You can find more information about Schneider Electric on their website: https://www.schneider-electric.com/", "Where can I find more information about Schneider Electric?" }
                });

            migrationBuilder.InsertData(
                table: "Feedback",
                columns: new[] { "FeedbackId", "FeedbackComment", "FeedbackDate", "FeedbackValue", "UserId" },
                values: new object[,]
                {
                    { 1, "HAMADA SA7 EL SA7", new DateTime(2019, 9, 7, 8, 0, 0, 0, DateTimeKind.Unspecified), 10, 1 },
                    { 2, "HAMADA SA7 EL SA7 2 ", new DateTime(2023, 9, 7, 8, 0, 0, 0, DateTimeKind.Unspecified), 9, 2 }
                });

            migrationBuilder.InsertData(
                table: "Resources",
                columns: new[] { "ResourceID", "CompanyPolicy", "ContactInfo", "UsefulLink" },
                values: new object[] { 1, "Schneider Electric has a number of company policies that are designed to ensure that the company operates in an ethical and responsible manner. These policies cover a wide range of topics, including:\r\n\r\nAnti-corruption\r\nAnti-harassment and anti-discrimination\r\nGifts and hospitality\r\nDiversity and inclusion\r\nEnergy\r\nEnvironment\r\nHuman rights\r\nQuality\r\nHealth and safety\r\nWhistleblowing", "18773425173", "https://www.se.com/us/en/all-products , https://www.se.com/us/en/work/solutions/ , https://www.se.com/us/en/work/services/ , https://blog.se.com/ , https://www.se.com/us/en/work/services/register-your-product/ , https://schneiderele.taleo.net/careersection/2/jobsearch.ftl?lang=en&keyword=&CATEGORY=-1&LOCATION=-1 , https://download.schneider-electric.com/files?p_Doc_Ref=NAM-Promo-terms-and-conditions" });

            migrationBuilder.InsertData(
                table: "Role",
                columns: new[] { "RoleId", "new_employee", "title" },
                values: new object[,]
                {
                    { 1, false, "Admin" },
                    { 2, false, "Manager" },
                    { 3, false, "Employee" },
                    { 4, true, "NewEmployee" }
                });

            migrationBuilder.InsertData(
                table: "User",
                columns: new[] { "UserId", "FirsttimeLogin", "Name", "RoleId", "age", "buddyId", "email", "enrollment_date", "is_buddy", "job_title", "new_employee", "password", "phoneNum" },
                values: new object[,]
                {
                    { 1, false, "Tarek Sherif", 1, 35, 0, "Tareksh@SE.com", new DateTime(2014, 3, 1, 8, 0, 0, 0, DateTimeKind.Unspecified), false, "Admin", false, "TarekSE1", 123010010 },
                    { 2, false, "Mostafa Hosny", 1, 34, 0, "Mostafa@SE.com", new DateTime(2015, 9, 7, 8, 0, 0, 0, DateTimeKind.Unspecified), false, "Admin", false, "MostafaH15", 123456123 },
                    { 3, false, "Hamza Hussein", 2, 28, 0, "HamzaHuss@SE.com", new DateTime(2017, 1, 1, 8, 0, 0, 0, DateTimeKind.Unspecified), false, "Manager", false, "Tarek10", 101001010 },
                    { 4, false, "Ahmad Mohamed", 2, 28, 0, "Ahmad@SE.com", new DateTime(2019, 9, 7, 8, 0, 0, 0, DateTimeKind.Unspecified), false, "Manager", false, "hamada10", 101001010 },
                    { 5, false, "Youssef Fouad", 2, 27, 0, "YoussefF@SE.com", new DateTime(2019, 9, 7, 8, 0, 0, 0, DateTimeKind.Unspecified), true, "Manager", false, "Youssef10", 10245974 },
                    { 6, false, "Salma Ihab", 2, 24, 0, "SalmaI@SE.com", new DateTime(2022, 8, 15, 8, 0, 0, 0, DateTimeKind.Unspecified), true, "Manager", false, "Salma10", 102557940 },
                    { 7, false, "Jessy Khaled", 2, 26, 0, "HabibaM@SE.com", new DateTime(2020, 2, 7, 8, 0, 0, 0, DateTimeKind.Unspecified), true, "Manager", false, "Habiba10", 105886414 },
                    { 8, true, "Lesya Kolyada", 3, 25, 6, "LesyaK@SE.com", new DateTime(2023, 9, 7, 8, 0, 0, 0, DateTimeKind.Unspecified), false, "Employee", false, "Lesya10", 1010678010 },
                    { 9, true, "Homos Awadallah", 3, 25, 7, "homos@SE.com", new DateTime(2023, 9, 7, 8, 0, 0, 0, DateTimeKind.Unspecified), false, "Employee", true, "homos10", 1010678010 },
                    { 10, true, "Talya Hany", 3, 25, 0, "TalyH@SE.com", new DateTime(2023, 9, 7, 8, 0, 0, 0, DateTimeKind.Unspecified), false, "Employee", false, "Talya10", 1010678010 },
                    { 11, true, "Mohamed Hassan", 3, 25, 0, "MohamedH@SE.com", new DateTime(2023, 9, 7, 8, 0, 0, 0, DateTimeKind.Unspecified), false, "Employee", true, "MohamedH10", 1010678010 },
                    { 12, true, "Ahmed Mostafa", 3, 24, 0, "AhmedM@SE.com", new DateTime(2023, 9, 7, 8, 0, 0, 0, DateTimeKind.Unspecified), false, "Employee", false, "AhmedM", 856745515 },
                    { 13, true, "Hana Aly", 4, 26, 6, "HanaA@SE.com", new DateTime(2023, 9, 7, 8, 0, 0, 0, DateTimeKind.Unspecified), false, "Employee", true, "HanaA10", 1447894642 },
                    { 14, true, "Omar Abu Gabal", 4, 25, 6, "OmarAG@SE.com", new DateTime(2023, 9, 7, 8, 0, 0, 0, DateTimeKind.Unspecified), false, "Employee", false, "OmarAG10", 223474980 },
                    { 15, true, "Youssef Hawary", 4, 26, 0, "YoussefH@SE.com", new DateTime(2023, 9, 7, 8, 0, 0, 0, DateTimeKind.Unspecified), false, "Employee", true, "Youssef10", 545465456 },
                    { 16, true, "Amaal Hassan", 4, 25, 0, "AmaalH@SE.com", new DateTime(2023, 9, 7, 8, 0, 0, 0, DateTimeKind.Unspecified), false, "Employee", false, "AmaalH10", 101025610 },
                    { 17, true, "Ahmed Tanbouly", 4, 25, 0, "AhmedT@SE.com", new DateTime(2023, 9, 7, 8, 0, 0, 0, DateTimeKind.Unspecified), false, "Employee", true, "AhmedT10", 155787618 },
                    { 18, true, "Donia El-0Karany", 4, 22, 7, "Donia-K@SE.com", new DateTime(2023, 9, 7, 8, 0, 0, 0, DateTimeKind.Unspecified), false, "Employee", false, "Donia10", 1017745610 },
                    { 23, false, "Basel Nabil", 2, 21, 0, "basel@SE.com", new DateTime(2019, 8, 7, 8, 0, 0, 0, DateTimeKind.Unspecified), false, "Mananger", false, "bas1234", 118846987 },
                    { 24, false, "Eng. Zezo", 1, 22, 0, "Zezo@SE.com", new DateTime(2023, 9, 7, 8, 0, 0, 0, DateTimeKind.Unspecified), false, "Admin", false, "Zezo22312", 118463323 },
                    { 26, true, "Ali Yasser", 3, 20, 0, "AliYasser@SE.com", new DateTime(2023, 9, 7, 8, 0, 0, 0, DateTimeKind.Unspecified), false, "Employee", true, "MostafaH445", 1225544963 },
                    { 27, false, "Adel Mohamed", 4, 20, 26, "adel@SE.com", new DateTime(2023, 9, 7, 8, 0, 0, 0, DateTimeKind.Unspecified), false, "New Employee", false, "adel3321", 555497678 },
                    { 28, true, "Youssef Seyam", 4, 25, 12, "YoussefSeyam@SE.com", new DateTime(2023, 9, 7, 8, 0, 0, 0, DateTimeKind.Unspecified), false, "New Employee", true, "YoussefSE00929", 11134455 },
                    { 29, false, "Afify Mohamed", 2, 22, 11, "afify@SE.com", new DateTime(2023, 9, 7, 8, 0, 0, 0, DateTimeKind.Unspecified), false, "New Employee", false, "afify77373", 11544666 },
                    { 32, false, "Ali Hamada", 2, 20, 26, "Alihamada@SE.com", new DateTime(2023, 9, 7, 8, 0, 0, 0, DateTimeKind.Unspecified), false, "Manager", true, "HanaA10", 44115572 },
                    { 38, false, "Mohamed Afifi", 2, 240, 0, "MohAfifi@SE.com", new DateTime(2023, 9, 7, 8, 0, 0, 0, DateTimeKind.Unspecified), false, "Manager", false, "MohAfifi@Schneider.com", 56153121 },
                    { 45, false, "Habiba Mohamed", 2, 22, 0, "HabibaM@SE.com", new DateTime(2023, 9, 7, 8, 0, 0, 0, DateTimeKind.Unspecified), false, "Manager", true, "Youssef10", 65656554 }
                });

            migrationBuilder.InsertData(
                table: "log",
                columns: new[] { "Id", "action", "actor", "time_of_occurance" },
                values: new object[,]
                {
                    { 1, "fired", "Mostafa Hosny", new DateTime(2019, 9, 7, 8, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 2, "fired", "Ahmad Mohamed", new DateTime(2019, 9, 7, 8, 0, 0, 0, DateTimeKind.Unspecified) },
                    { 3, "fired", "Homos Awadallah", new DateTime(2019, 9, 7, 8, 0, 0, 0, DateTimeKind.Unspecified) }
                });

            migrationBuilder.InsertData(
                table: "Question",
                columns: new[] { "QuestionId", "CourseId", "QuestionText", "Wrong_choice1", "Wrong_choice2", "Wrong_choice3", "correct_choice" },
                values: new object[,]
                {
                    { 1, 3, "What is the purpose of a VLAN?", "To create separate security zones on a network", "To create separate routing domains on a network", "None of the above", "To create separate broadcast domains on a network" },
                    { 2, 3, "Which of the following is a type of network topology?", "Star", "Ring", "Mesh", "All of the above" },
                    { 3, 3, "Which of the following is the default subnet mask for a Class C IP address?", ". 255.255.0.0", "255.0.0.0", "192.168.0.0", "255.255.255.0" },
                    { 4, 3, "Which routing protocol uses cost as its metric?", "OSPF", "RIP", "BGP", "EIGRP" },
                    { 5, 3, "Which of the following is a type of network traffic?", "VOIP", "HTTP", "FTP", "All of the above" },
                    { 6, 3, "Which of the following is the OSI model layer responsible for providing reliable communication between two hosts?", "Physical layer", "Data link layer", "Network layer", "Transport layer" },
                    { 7, 3, "Which command is used to view the MAC address table on a Cisco switch?", "Show IP route", "Show interfaces", "Show running-config", "Show MAC address-table" },
                    { 8, 3, "Which of the following is a private IP address range?", "10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "All of the above" },
                    { 9, 3, "Which of the following is a Layer 2 switch?", "Cisco 3750", "Cisco 4500", "Cisco 7600", "Cisco 2960" },
                    { 10, 3, "What is the default administrative distance for OSPF?", "10", "100", "110", "1" },
                    { 11, 3, "Which of the following is a routing protocol that is based on distance vector?", "OSPF", "EIGRP", "BGP", "RIP" },
                    { 12, 3, "Which command is used to configure a static route on a Cisco router?", "Route add", "IP static", "Route", "IP route" },
                    { 13, 3, "Which of the following is a type of network security appliance?", "Switch", "Router", "Hub", "Firewall" },
                    { 14, 3, "What is the purpose of a DHCP server?", "To route traffic between different networks", "To provide name resolution services", "To provide security for a network", "To assign IP addresses to hosts on a network" },
                    { 15, 3, "What is the purpose of a spanning tree protocol?", "To provide load balancing for a network", "To provide security for a network", "To provide fault tolerance for a network", "To prevent loops in a network" }
                });

            migrationBuilder.InsertData(
                table: "User_Course",
                columns: new[] { "CourseId", "UserId" },
                values: new object[,]
                {
                    { 1, 14 },
                    { 2, 15 },
                    { 3, 16 },
                    { 4, 17 },
                    { 5, 15 },
                    { 6, 18 },
                    { 7, 17 },
                    { 8, 18 },
                    { 9, 27 },
                    { 10, 28 },
                    { 11, 29 }
                });

            migrationBuilder.InsertData(
                table: "lecture",
                columns: new[] { "LectureId", "CourseId", "LectureName", "URL" },
                values: new object[,]
                {
                    { 1, 1, "Lecture1", "https://www.youtube.com/embed/IDDmrzzB14M" },
                    { 2, 1, "Lecture2", "https://www.youtube.com/embed/ywg7cW0Txs4" },
                    { 3, 1, "Lecture3", "https://www.youtube.com/embed/XmYnsO7iSI8" },
                    { 4, 1, "Lecture4", "https://www.youtube.com/embed/4oqjcKenCH8" },
                    { 5, 1, "Lecture5", "https://www.youtube.com/embed/AcWIE9qazLI" },
                    { 6, 1, "Lecture6", "https://www.youtube.com/embed/X8h4dq9Hzq8" },
                    { 7, 1, "Lecture7", "https://www.youtube.com/embed/5Jppcxc1Qzc" },
                    { 8, 1, "Lecture8", "https://www.youtube.com/embed/zrCLRC3Ci1c" },
                    { 9, 1, "Lecture9", "https://www.youtube.com/embed/alnzFK-4xMY" },
                    { 10, 1, "Lecture10", "https://www.youtube.com/embed/Kuy4cEXpXEE" },
                    { 11, 1, "Lecture11", "https://www.youtube.com/embed/oVA0fD13NGI" },
                    { 12, 1, "Lecture12", "https://www.youtube.com/embed/iXG0sXlzuF0" },
                    { 13, 2, "Lecture1", "https://www.youtube.com/embed/CB3XOsaTEbM" },
                    { 14, 2, "Lecture2", "https://www.youtube.com/embed/Vgmq7rDh7a0" },
                    { 15, 2, "Lecture3", "https://www.youtube.com/embed/Yo-P7YD0Fdo" },
                    { 16, 2, "Lecture4", "https://www.youtube.com/embed/UyWDqZODprk" },
                    { 17, 2, "Lecture5", "https://www.youtube.com/embed/aOB2nmuICJo" },
                    { 18, 2, "Lecture6", "https://www.youtube.com/embed/w_57TIwRQPg" },
                    { 19, 2, "Lecture7", "https://www.youtube.com/embed/kkLUhz9pXi0" },
                    { 20, 2, "Lecture8", "https://www.youtube.com/embed/7gLHa_ShHWU" },
                    { 21, 2, "Lecture9", "https://www.youtube.com/embed/zyA2zjFYC9I" },
                    { 22, 2, "Lecture10", "https://www.youtube.com/embed/qv07isP7aZQ" },
                    { 23, 2, "Lecture11", "https://www.youtube.com/embed/JdXJhNI43SY" },
                    { 24, 2, "Lecture12", "https://www.youtube.com/embed/uBgptTSejD4" },
                    { 25, 2, "Lecture13", "https://www.youtube.com/embed/5DZ6RCa6Eaw" },
                    { 26, 2, "Lecture14", "https://www.youtube.com/embed/Z8F4_191pCU" },
                    { 27, 2, "Lecture15", "https://www.youtube.com/embed/6gV6_TI85sk" },
                    { 28, 2, "Lecture16", "https://www.youtube.com/embed/UIKdmGMG42U" },
                    { 29, 2, "Lecture17", "https://www.youtube.com/embed/ELS_QdbqF_Q" },
                    { 30, 2, "Lecture18", "https://www.youtube.com/embed/-IUDQBvtqc8" },
                    { 31, 2, "Lecture19", "https://www.youtube.com/embed/IlxcSHCFECY" },
                    { 32, 2, "Lecture20", "https://www.youtube.com/embed/dhN1j7ZgnAI" },
                    { 33, 2, "Lecture21", "https://www.youtube.com/embed/wbZGVI0CSb4" },
                    { 34, 2, "Lecture22", "https://www.youtube.com/embed/-70mkrY_Tz8" },
                    { 35, 2, "Lecture23", "https://www.youtube.com/embed/BdZrC_RwVGU" },
                    { 36, 2, "Lecture24", "https://www.youtube.com/embed/ja_KmhIP_M4" },
                    { 37, 2, "Lecture25", "https://www.youtube.com/embed/ksYE8aMkp90" },
                    { 38, 2, "Lecture26", "https://www.youtube.com/embed/PbYIOZNNZtE" },
                    { 39, 2, "Lecture27", "https://www.youtube.com/embed/VckwZSMetRA" },
                    { 40, 2, "Lecture28", "https://www.youtube.com/embed/t-BeD-7LU0I" },
                    { 41, 2, "Lecture29", "https://www.youtube.com/embed/wCmnnV7DU6Q" },
                    { 42, 3, "Lecture1", "https://www.youtube.com/embed/S7MNX_UD7vY" },
                    { 43, 3, "Lecture2", "https://www.youtube.com/embed/9eH16Fxeb9o" },
                    { 44, 3, "Lecture3", "https://www.youtube.com/embed/p9ScLm9S3B4" },
                    { 45, 3, "Lecture4", "https://www.youtube.com/embed/CRdL1PcherM" },
                    { 46, 3, "Lecture5", "https://www.youtube.com/embed/3kfO61Mensg" },
                    { 47, 3, "Lecture6", "https://www.youtube.com/embed/oIRkXulqJA4" },
                    { 48, 3, "Lecture7", "https://www.youtube.com/embed/xPi4uZu4uF0" },
                    { 51, 3, "Lecture10", "https://www.youtube.com/embed/80vIin4xGp8" },
                    { 52, 3, "Lecture11", "https://www.youtube.com/embed/37tyxaQbtN4" },
                    { 53, 3, "Lecture12", "https://www.youtube.com/embed/y8h5qY3zwic" },
                    { 54, 3, "Lecture13", "https://www.youtube.com/embed/MLxgmkRzgIQ" },
                    { 55, 3, "Lecture14", "https://www.youtube.com/embed/MLxgmkRzgIQ" },
                    { 56, 3, "Lecture15", "https://www.youtube.com/embed/E3DEJ7odWq0" },
                    { 57, 3, "Lecture16", "https://www.youtube.com/embed/0W4JZIWtjLQ" },
                    { 58, 3, "Lecture17", "https://www.youtube.com/embed/5WfiTHiU4x8" },
                    { 59, 3, "Lecture18", "https://www.youtube.com/embed/tcae4TSSMo8" },
                    { 60, 3, "Lecture19", "https://www.youtube.com/embed/8bhvn9tQk8o" },
                    { 61, 3, "Lecture20", "https://www.youtube.com/embed/2-i5x8KCfII" },
                    { 62, 3, "Lecture21", "https://www.youtube.com/embed/oZGZRtaGyG8" },
                    { 63, 3, "Lecture22", "https://www.youtube.com/embed/mJ_5qeqGOaI" },
                    { 64, 3, "Lecture23", "https://www.youtube.com/embed/B1vqKQIPxr0" },
                    { 65, 4, "Lecture1", "https://youtu.be/hu-q2zYwEYs" },
                    { 66, 4, "Lecture2", "https://youtu.be/mbeT8mpmtHA" },
                    { 67, 4, "Lecture3", "https://youtu.be/YwbIeMlxZAU" },
                    { 68, 4, "Lecture4", "https://youtu.be/D3iEE29ZXRM" },
                    { 69, 4, "Lecture5", "https://youtu.be/FHZn6706e3Q" },
                    { 70, 4, "Lecture6", "https://youtu.be/kGW8Al_cga4" },
                    { 71, 4, "Lecture7", "https://youtu.be/25R1Jl5P7Mw" },
                    { 72, 4, "Lecture8", "https://youtu.be/XQaHAAXIVg8" },
                    { 73, 4, "Lecture9", "https://youtu.be/FMu2cKWD90g" },
                    { 74, 4, "Lecture10", "https://youtu.be/Xig7NsIE6DI" },
                    { 75, 4, "Lecture11", "https://youtu.be/qES0HypsUK0" },
                    { 76, 5, "Lecture1", "https://youtu.be/zb3Qk8SG5Ms" },
                    { 77, 5, "Lecture2", "https://youtu.be/OIBIXYLJjsI" },
                    { 78, 5, "Lecture3", "https://youtu.be/-HPZ1leCV8k" },
                    { 79, 5, "Lecture4", "https://youtu.be/DQD00NAUPNk" },
                    { 80, 5, "Lecture5", "https://youtu.be/bdHE2wHT-gQ" },
                    { 81, 5, "Lecture6", "https://youtu.be/Lr9WUkeYSA8" },
                    { 82, 5, "Lecture7", "https://youtu.be/yXEesONd_54" },
                    { 83, 5, "Lecture8", "https://youtu.be/_GJKAs7A0_4" },
                    { 84, 5, "Lecture9", "https://youtu.be/bxsemcrY4gQ" },
                    { 85, 5, "Lecture10", "https://youtu.be/VVGgacjzc2Y" },
                    { 86, 5, "Lecture11", "https://youtu.be/zW_tZR0Ir3Q" },
                    { 87, 5, "Lecture12", "https://youtu.be/nYAyhRAV87A" },
                    { 88, 6, "Lecture1", "https://youtu.be/j89BvWz8Eag" },
                    { 89, 6, "Lecture2", "https://youtu.be/JjWRNtBorMw" },
                    { 90, 6, "Lecture3", "https://youtu.be/kvm8tsRj6BM" },
                    { 91, 6, "Lecture4", "https://youtu.be/kvm8tsRj6BM" },
                    { 92, 6, "Lecture5", "https://youtu.be/JrZfUktGano" },
                    { 93, 6, "Lecture6", "https://youtu.be/de6Q0I4yMI8" },
                    { 94, 6, "Lecture7", "https://youtu.be/ULMH3lxygXY" },
                    { 95, 6, "Lecture8", "https://youtu.be/tx4NHrhJK_Q" },
                    { 96, 6, "Lecture9", "https://youtu.be/p8HML9W2F6E" },
                    { 97, 6, "Lecture10", "https://youtu.be/Dzn5BjAcCB0" },
                    { 98, 6, "Lecture11", "https://youtu.be/lLM6ozP8UXE" },
                    { 99, 6, "Lecture12", "https://youtu.be/mblT909451o" },
                    { 100, 6, "Lecture13", "https://youtu.be/ulouRaA0tHc" },
                    { 101, 6, "Lecture14", "https://youtu.be/MMRjLubm4GY" },
                    { 102, 6, "Lecture15", "https://youtu.be/0IPbKyLVDh4" },
                    { 103, 6, "Lecture16", "https://youtu.be/yf0LLFg2rqk" },
                    { 104, 6, "Lecture17", "https://youtu.be/3la8rtPF5gU" },
                    { 105, 6, "Lecture18", "https://youtu.be/2ZDK6v2FZlI" },
                    { 106, 6, "Lecture19", "https://youtu.be/PTlCq7GEpCo" },
                    { 107, 6, "Lecture20", "https://youtu.be/FcOa2G9kJPE" },
                    { 108, 6, "Lecture21", "https://youtu.be/ojx-0zVeIr4" },
                    { 109, 6, "Lecture22", "https://youtu.be/ZFXCM2ttZh4" },
                    { 110, 6, "Lecture23", "https://youtu.be/YVdA86aSBGY" },
                    { 111, 6, "Lecture24", "https://youtu.be/0JZ6EW-QrJw" },
                    { 112, 6, "Lecture25", "https://youtu.be/safz1yCVYxo" },
                    { 113, 6, "Lecture26", "https://youtu.be/RBWe_ZlSzjQ" },
                    { 114, 7, "Lecture1", "https://youtu.be/8vTCyhDyRjg" },
                    { 115, 7, "Lecture2", "https://youtu.be/TuZ0lkMLQQA" },
                    { 116, 7, "Lecture3", "https://youtu.be/kLIOUXxvJ9E" },
                    { 117, 7, "Lecture4", "https://youtu.be/_S6CITm-h6w" },
                    { 118, 7, "Lecture5", "https://youtu.be/Yp1MKeIG-M4" },
                    { 119, 7, "Lecture6", "https://youtu.be/Yp1MKeIG-M4" },
                    { 120, 7, "Lecture7", "https://youtu.be/IneUOPTjSRc" },
                    { 121, 7, "Lecture8", "https://youtu.be/84KXr0zi56g" },
                    { 122, 7, "Lecture9", "https://youtu.be/84KXr0zi56g" },
                    { 123, 7, "Lecture10", "https://youtu.be/t9KheZYSBYc" },
                    { 124, 7, "Lecture11", "https://youtu.be/2SYyb6gNpfg" },
                    { 125, 7, "Lecture12", "https://youtu.be/xGuAAp4J3UE" },
                    { 126, 7, "Lecture13", "https://youtu.be/Ma9DW01DheA" },
                    { 127, 7, "Lecture15", "https://youtu.be/cYqBBAYNdk8" },
                    { 128, 7, "Lecture16", "https://youtu.be/yGbF79TedtI" },
                    { 129, 7, "Lecture14", "https://youtu.be/IMK9hHEB0Cs" },
                    { 130, 8, "Lecture1", "https://youtu.be/zBPeGR48_vE" },
                    { 131, 8, "Lecture2", "https://youtu.be/sEGC-adSKXo" },
                    { 132, 8, "Lecture3", "https://youtu.be/sEGC-adSKXo" },
                    { 133, 8, "Lecture4", "https://youtu.be/plOo5hNVQJU" },
                    { 134, 8, "Lecture5", "https://youtu.be/yjE_xXL26qA" },
                    { 135, 8, "Lecture6", "https://youtu.be/jfQyMPzPTjY" },
                    { 136, 8, "Lecture7", "https://youtu.be/nMQlXMHMz_Y" },
                    { 137, 8, "Lecture8", "https://youtu.be/S2JVtEwa-kU" },
                    { 138, 8, "Lecture9", "https://youtu.be/yPJCFWLd23o" },
                    { 139, 8, "Lecture10", "https://youtu.be/yPJCFWLd23o" },
                    { 140, 8, "Lecture11", "https://youtu.be/Fk3tdDAWkCI" },
                    { 141, 8, "Lecture12", "https://youtu.be/sQ7YA0x8eUg" },
                    { 142, 8, "Lecture13", "https://youtu.be/wCijt0OjnHc" },
                    { 143, 8, "Lecture14", "https://youtu.be/onTQRpF15hI" },
                    { 144, 8, "Lecture15", "https://youtu.be/CNGv0soYFn0" },
                    { 145, 8, "Lecture16", "https://youtu.be/CNohrcgM_hU" },
                    { 146, 8, "Lecture17", "https://youtu.be/3Uy5cJ-UpS0" },
                    { 147, 8, "Lecture18", "https://youtu.be/RNrrcxr-_PU" },
                    { 148, 8, "Lecture19", "https://youtu.be/G0PC7D3XZBA" },
                    { 149, 8, "Lecture20", "https://youtu.be/DeFK4lS5LIA" },
                    { 150, 8, "Lecture21", "https://youtu.be/jfC2tX-NUaI" },
                    { 151, 8, "Lecture22", "https://youtu.be/n5mvncHb-Y0" },
                    { 152, 8, "Lecture23", "https://youtu.be/MBLCbJvyaA0" },
                    { 153, 8, "Lecture24", "https://youtu.be/1HEG5bvjJIA" },
                    { 154, 8, "Lecture25", "https://youtu.be/1HEG5bvjJIA" },
                    { 155, 8, "Lecture26", "https://youtu.be/hjWt3PQktJ8" },
                    { 156, 8, "Lecture27", "https://youtu.be/LWeRIGGRZVk" },
                    { 157, 8, "Lecture28", "https://youtu.be/tM4aKXtaOrE" },
                    { 158, 8, "Lecture29", "https://youtu.be/_AQ9RBQcNMA" },
                    { 159, 8, "Lecture30", "https://youtu.be/eOCfFxLGS-o" },
                    { 160, 8, "Lecture31", "https://youtu.be/hZF_0dZnpvo" },
                    { 161, 8, "Lecture32", "https://youtu.be/Sm4AZFIc39Y" },
                    { 162, 8, "Lecture33", "https://youtu.be/EQJ4w3ypF9o" },
                    { 164, 9, "Lecture1", "https://www.youtube.com/watch?v=c8_avX9miag&list=PLN55WL2iKzD6E3rW7HtI-VZzLZFzbJP3f" },
                    { 165, 9, "Lecture2", "https://www.youtube.com/watch?v=rVyJXnZEp2A&list=PLN55WL2iKzD6E3rW7HtI-VZzLZFzbJP3f&index=2" },
                    { 166, 9, "Lecture3", "https://www.youtube.com/watch?v=awuJ2O2SLUs&list=PLN55WL2iKzD6E3rW7HtI-VZzLZFzbJP3f&index=3" },
                    { 167, 9, "Lecture4", "https://www.youtube.com/watch?v=to0b5yZtchc&list=PLN55WL2iKzD6E3rW7HtI-VZzLZFzbJP3f&index=4" },
                    { 168, 9, "Lecture5", "https://www.youtube.com/watch?v=FwJ3n6KvK1A&list=PLN55WL2iKzD6E3rW7HtI-VZzLZFzbJP3f&index=5" },
                    { 169, 9, "Lecture6", "https://www.youtube.com/watch?v=iY6e_NDCJgM&list=PLN55WL2iKzD6E3rW7HtI-VZzLZFzbJP3f&index=6" },
                    { 170, 9, "Lecture7", "https://www.youtube.com/watch?v=VZ-MSZXnUiw&list=PLN55WL2iKzD6E3rW7HtI-VZzLZFzbJP3f&index=7" },
                    { 171, 9, "Lecture8", "https://www.youtube.com/watch?v=Pk8hN7lw_RA&list=PLN55WL2iKzD6E3rW7HtI-VZzLZFzbJP3f&index=8" },
                    { 172, 9, "Lecture9", "https://www.youtube.com/watch?v=9zQTC8bBEhs&list=PLN55WL2iKzD6E3rW7HtI-VZzLZFzbJP3f&index=9" },
                    { 173, 9, "Lecture10", "https://www.youtube.com/watch?v=9zQTC8bBEhs&list=PLN55WL2iKzD6E3rW7HtI-VZzLZFzbJP3f&index=10" },
                    { 174, 9, "Lecture11", "https://www.youtube.com/watch?v=9zQTC8bBEhs&list=PLN55WL2iKzD6E3rW7HtI-VZzLZFzbJP3f&index=11" },
                    { 175, 9, "Lecture12", "https://www.youtube.com/watch?v=9zQTC8bBEhs&list=PLN55WL2iKzD6E3rW7HtI-VZzLZFzbJP3f&index=12" },
                    { 176, 9, "Lecture13", "https://www.youtube.com/watch?v=9zQTC8bBEhs&list=PLN55WL2iKzD6E3rW7HtI-VZzLZFzbJP3f&index=13" },
                    { 177, 9, "Lecture14", "https://www.youtube.com/watch?v=9zQTC8bBEhs&list=PLN55WL2iKzD6E3rW7HtI-VZzLZFzbJP3f&index=14" },
                    { 178, 9, "Lecture15", "https://www.youtube.com/watch?v=9zQTC8bBEhs&list=PLN55WL2iKzD6E3rW7HtI-VZzLZFzbJP3f&index=15" },
                    { 179, 9, "Lecture16", "https://www.youtube.com/watch?v=9zQTC8bBEhs&list=PLN55WL2iKzD6E3rW7HtI-VZzLZFzbJP3f&index=16" },
                    { 180, 9, "Lecture16", "https://www.youtube.com/watch?v=9zQTC8bBEhs&list=PLN55WL2iKzD6E3rW7HtI-VZzLZFzbJP3f&index=16" },
                    { 181, 9, "Lecture17", "https://www.youtube.com/watch?v=9zQTC8bBEhs&list=PLN55WL2iKzD6E3rW7HtI-VZzLZFzbJP3f&index=17" },
                    { 182, 9, "Lecture18", "https://www.youtube.com/watch?v=9zQTC8bBEhs&list=PLN55WL2iKzD6E3rW7HtI-VZzLZFzbJP3f&index=18" },
                    { 183, 9, "Lecture19", "https://www.youtube.com/watch?v=9zQTC8bBEhs&list=PLN55WL2iKzD6E3rW7HtI-VZzLZFzbJP3f&index=19" },
                    { 184, 9, "Lecture1", "https://www.youtube.com/watch?v=QTcFvi3LswE&list=PL9-f9hWLZS62VF18qPQ1gC7NqIAjaClsl" },
                    { 185, 9, "Lecture2", "https://youtu.be/V76lKFm_gYI" },
                    { 186, 9, "Lecture3", "https://youtu.be/cE0T-XPEcyI" },
                    { 187, 9, "Lecture4", "https://youtu.be/RCbZjPHC1gg" },
                    { 188, 9, "Lecture5", "https://youtu.be/k9kdw77vbek" },
                    { 189, 9, "Lecture6", "https://youtu.be/4ceMVqbiKqA" },
                    { 190, 9, "Lecture7", "https://youtu.be/dx5iOfkvZcA" },
                    { 191, 11, "Lecture1", "https://youtu.be/RabOe1KTlm8" },
                    { 192, 11, "Lecture2", "https://youtu.be/RabOe1KTlm8" },
                    { 193, 11, "Lecture3", "https://youtu.be/u6Xcu5-WXKc" },
                    { 194, 11, "Lecture4", "https://youtu.be/Bpd2r6ZxFOc" },
                    { 195, 11, "Lecture5", "https://youtu.be/TXoIoUfBN34" },
                    { 196, 11, "Lecture6", "https://youtu.be/msefXfRSGOE" },
                    { 197, 11, "Lecture7", "https://youtu.be/Blu8gTqmbEA" },
                    { 198, 11, "Lecture8", "https://youtu.be/AUvetlVvT5I" },
                    { 199, 11, "Lecture9", "https://youtu.be/MdGd6jun-j8" },
                    { 200, 11, "Lecture10", "https://youtu.be/pwnORiU-_Hg" },
                    { 201, 12, "Lecture1", "https://youtu.be/TKoLoLVI_Js" },
                    { 202, 12, "Lecture2", "https://youtu.be/TKoLoLVI_Js" },
                    { 203, 12, "Lecture3", "https://youtu.be/y_T3kubRm7Q" },
                    { 204, 12, "Lecture4", "https://youtu.be/TKoLoLVI_Js" },
                    { 205, 12, "Lecture5", "https://youtu.be/BbdbjW8Pq04" },
                    { 206, 12, "Lecture6", "https://youtu.be/PMENh4UWr-Y" },
                    { 207, 12, "Lecture7", "https://youtu.be/rBWBUKZd4WY" },
                    { 208, 12, "Lecture8", " https://youtu.be/82V2CafoYs0" },
                    { 209, 12, "Lecture9", "https://youtu.be/GbpHHt08obE" },
                    { 210, 12, "Lecture10", "https://youtu.be/4UKaQpe1Yfs" },
                    { 211, 12, "Lecture11", "https://youtu.be/0IlSi0pyQD4" },
                    { 212, 12, "Lecture12", "https://youtu.be/FXbXksS4kNs" },
                    { 213, 13, "Lecture1", "https://youtu.be/MSend7ZUtfQ" },
                    { 214, 13, "Lecture2", "https://youtu.be/u41V1QamyqE" },
                    { 215, 13, "Lecture3", "https://youtu.be/-SeeEIvOYxc" },
                    { 216, 13, "Lecture4", "https://youtu.be/5GbLoNHKNGE" },
                    { 217, 13, "Lecture5", "https://youtu.be/sgFViiFPMDA" },
                    { 218, 13, "Lecture6", "https://youtu.be/sgFViiFPMDA" },
                    { 219, 13, "Lecture7", "https://youtu.be/P2xV38Qy7ug" },
                    { 220, 13, "Lecture8", "https://youtu.be/4Y5BBN6Pwv0" },
                    { 221, 13, "Lecture9", "https://youtu.be/crc9ZrKf5lA" },
                    { 222, 13, "Lecture10", "https://youtu.be/sgFViiFPMDA" },
                    { 223, 13, "Lecture11", "https://youtu.be/WkNiJmqJbEM" },
                    { 224, 13, "Lecture12", "https://youtu.be/fdtD0dz28zY" }
                });

            migrationBuilder.CreateIndex(
                name: "IX_lecture_CourseId",
                table: "lecture",
                column: "CourseId");

            migrationBuilder.CreateIndex(
                name: "IX_Question_CourseId",
                table: "Question",
                column: "CourseId");

            migrationBuilder.CreateIndex(
                name: "IX_Userlog_usersUserId",
                table: "Userlog",
                column: "usersUserId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Departments");

            migrationBuilder.DropTable(
                name: "FAQ");

            migrationBuilder.DropTable(
                name: "Feedback");

            migrationBuilder.DropTable(
                name: "lecture");

            migrationBuilder.DropTable(
                name: "Question");

            migrationBuilder.DropTable(
                name: "Reports");

            migrationBuilder.DropTable(
                name: "Resources");

            migrationBuilder.DropTable(
                name: "Role");

            migrationBuilder.DropTable(
                name: "User_Course");

            migrationBuilder.DropTable(
                name: "Userlog");

            migrationBuilder.DropTable(
                name: "Course");

            migrationBuilder.DropTable(
                name: "User");

            migrationBuilder.DropTable(
                name: "log");
        }
    }
}
