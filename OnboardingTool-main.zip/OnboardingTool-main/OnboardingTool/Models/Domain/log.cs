using System;
using System.Collections.Generic;
using System.Configuration;
using Microsoft.EntityFrameworkCore;

namespace OnboardingTool.Models.Domain
{
    public class log
    {
        public int Id { get; set; } 
        public string action { get; set; }
        public string actor { get; set; }
        public DateTime time_of_occurance { get; set; }
        public ICollection<User> users { get; set; } = new List<User>();
    }

}




