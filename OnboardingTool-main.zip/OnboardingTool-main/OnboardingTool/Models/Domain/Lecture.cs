﻿namespace OnboardingTool.Models.Domain
{
    public class Lecture
    {
        public int LectureId{ get; set; }
        
        public int CourseId { get; set; }
        
        public string LectureName { get; set; }
        
        public string URL { get; set; }
        public Course Course { get; set;}
    }
}
