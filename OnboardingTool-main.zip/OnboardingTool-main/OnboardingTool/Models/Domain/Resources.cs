﻿namespace OnboardingTool.Models.Domain
{
    public class Resources
    {
        public int ResourceID { get; set; }
        public string ContactInfo { get; set; }

        public string CompanyPolicy { get; set; }
 
        public string UsefulLink { get; set; }
    }
}
