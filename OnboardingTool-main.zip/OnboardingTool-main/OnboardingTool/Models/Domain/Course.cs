using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace OnboardingTool.Models.Domain
{
   
    public class Course
    {
        public int CourseId { get; set; }

        public string CourseName { get; set; }

        public string Description { get; set; }

        public ICollection<User_course>? user_courses { get; }
        public ICollection<Lecture> Lectures { get; }
        public ICollection<Question> Questions { get; }
        //public Lecture lectures { get; } = null!;
        //public Question? questions { get; } = null!;
    }
}
