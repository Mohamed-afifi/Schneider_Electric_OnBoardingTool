﻿namespace OnboardingTool.Models.Domain
{
    public class Feedback
    {
        public int FeedbackId { get; set; }

        public int FeedbackValue { get; set; }

        public string? FeedbackComment { get; set; }

        public int UserId { get; set; }

        public DateTime FeedbackDate { get; set; }

    }
}
