using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace OnboardingTool.Models.Domain
{
    public class Role
    {
        public string title { get; set; }
        public bool new_employee { get; set; }
        public int RoleId { get; set; }

    }
}
