﻿namespace OnboardingTool.Models.Domain
{
    public class Question
    {
        public int QuestionId { get; set; }
        public string QuestionText { get; set; }
        public string Wrong_choice1 { get; set; }
        public string Wrong_choice2 { get; set; }
        public string Wrong_choice3 { get; set; }
        public string correct_choice{ get; set; }
        public int CourseId { get; set; }
        public Course Course { get; set; }

    }
}
