using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace OnboardingTool.Models.Domain
{

    public class User_course
    {
        public int CourseId { get; set; }
        public int UserId { get; set; }

    }
}

