﻿
namespace OnboardingTool.Models.Domain
{
    public class Departments
    {
        public int DepartmentCode { get; set; }
        public string DepartmentName { get; set; }
        public string Description { get; set; }
    }
}
