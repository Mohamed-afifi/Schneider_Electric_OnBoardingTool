﻿    namespace OnboardingTool.Models.Domain
{
    public class Report
    {
        public int ReportId{ get; set; }
        public int UserId { get; set; }
        public string Description { get; set; }
    }
}
