using Microsoft.EntityFrameworkCore;

namespace OnboardingTool.Models.Domain
{
    public class User
    {
        public int UserId { get; set; }
        public string Name { get; set; }
        public string email { get; set; }
        public string password { get; set; }
        public int RoleId { get; set; }
        public int age { get; set; }
        public int phoneNum { get; set; }
        public string job_title { get; set; }
        public bool is_buddy { get; set; }
        public int buddyId { get; set; }
        public DateTime enrollment_date { get; set; }
        public ICollection<log> logs { get; } = new List<log>();
        public Feedback? feedbacks { get;  } = null!;
        public Departments? departments { get; }  
        public bool FirsttimeLogin { get; set; }
        public Boolean new_employee { get; set; }         
    }
}
